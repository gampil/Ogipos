const CACHE_NAME = 'ogipos-publik-09876-v2';
const PRECACHE = ["/offline.html", "/manifest.webmanifest", "/assets/09876/0ded71b4f2aa.js", "/assets/09876/34392f5ceede.css", "/assets/09876/7011f527fc86.js", "/assets/09876/7cef66410afc.css", "/assets/09876/b4ab21f9aeb3.css", "/assets/09876/c2059eecf24d.css", "/assets/09876/c4b4dfb4f7a8.css", "/assets/09876/fe4d2ec78ac6.js", "/assets/09876/gd.js", "/assets/icons/favicon.svg", "/assets/icons/icon-192.png", "/assets/icons/icon-512.png", "/assets/images/ogipos-logo.webp", "/assets/images/ogipos-social.png"];
const API_PATH = /^\/(?:v1|api|bayar|invoice|sukses|callback)(?:\/|$)/;

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.allSettled(PRECACHE.map(async path => {
      try {
        const response = await fetch(path, { cache: 'reload' });
        if (response.ok && response.type !== 'opaque') await cache.put(path, response);
      } catch (_) {}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('ogipos-') && name !== CACHE_NAME)
      .map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || API_PATH.test(url.pathname)) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(async () =>
      (await caches.match('/offline.html')) || Response.error()));
    return;
  }

  if (/^\/assets\//.test(url.pathname) || /\.(?:ico|webmanifest)$/.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);
      const network = fetch(request).then(response => {
        if (response.ok && response.type !== 'opaque') cache.put(request, response.clone());
        return response;
      }).catch(() => null);
      return cached || await network || Response.error();
    })());
  }
});
