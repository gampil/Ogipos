<?php
declare(strict_types=1);
namespace Ogipos;

/** Direct Sheets v4 and Drive v3 API, running in PHP on shared hosting, without GAS. */
final class TenantSheets
{
    public const SCHEMA = [
        'Transactions' => ['id','customer','phone','service','total','cashier','status','method','paymentStatus','cashPaid','cashChange','itemsDetail','date','estimatedPickup','cashierUid','customerId','subtotal','discount','grandTotal','tenantId'],
        'Customers' => ['id','name','phone','createdAt','updatedAt','cashierUid'],
        'Services' => ['id','name','price','type','icon','createdAt'],
        'Expenses' => ['id','tanggal','keterangan','nominal','sumber_dana'],
        'Meta' => ['key','value'],
    ];
    private array $cache = [];
    public function __construct(Store $store) { }
    private function sid(string $id): string
    {
        if (!preg_match('/^[A-Za-z0-9_-]{20,128}$/', $id)) throw new ApiError('ID Spreadsheet tidak valid.');
        return rawurlencode($id);
    }
    private function sheet(string $name): string
    {
        if (!isset(self::SCHEMA[$name])) throw new ApiError('Sheet tidak dikenal.');
        return $name;
    }
    private function su(string $id): string { return 'https://sheets.googleapis.com/v4/spreadsheets/' . $this->sid($id); }
    private function du(string $id = ''): string { return 'https://www.googleapis.com/drive/v3/files' . ($id !== '' ? '/' . $this->sid($id) : ''); }
    private function valueList(string $name, array $rows): array
    {
        $values = [];
        foreach ($rows as $row) {
            if (!is_array($row)) throw new ApiError('Baris spreadsheet tidak valid.');
            $values[] = array_map(static function ($key) use ($row) {
                $v = $row[$key] ?? '';
                if (is_array($v) || is_object($v)) $v = json_encode($v, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return $v === null || is_bool($v) ? (string) $v : $v;
            }, self::SCHEMA[$name]);
        }
        return $values;
    }
    private function checkMeta(string $id, string $tenantId, string $slug): void
    {
        $url = $this->su($id) . '/values/' . rawurlencode('Meta!A1:B30');
        $response = GoogleAccount::api('GET', $url);
        $meta = [];
        foreach (($response['values'] ?? []) as $row) if (count($row) > 1) $meta[(string) $row[0]] = (string) $row[1];
        if (($meta['tenantId'] ?? '') !== $tenantId || ($meta['slug'] ?? '') !== $slug) {
            throw new ApiError('Spreadsheet bukan milik tenant ini. Migrasi data diperlukan, sheet tidak diubah.', 409);
        }
    }
    /** Safe read-only verification: never link or overwrite a foreign tenant sheet. */
    public function verifyOwnership(string $id, string $tenantId, string $slug): void
    {
        $this->checkMeta($id, $tenantId, $slug);
    }

    /** Read ONLY headers, not thousands of data rows, for quick Owner diagnostics. */
    public function verifySchema(string $id): void
    {
        $ranges = [];
        foreach (['Transactions', 'Customers', 'Services', 'Expenses'] as $sheet) {
            $count = count(self::SCHEMA[$sheet]);
            $end = '';
            do { $end = chr(65 + ($count - 1) % 26) . $end; $count = intdiv($count - 1, 26); } while ($count > 0);
            $ranges[] = 'ranges=' . rawurlencode($sheet . '!A1:' . $end . '1');
        }
        $response = GoogleAccount::api('GET', $this->su($id) . '/values:batchGet?' . implode('&', $ranges));
        foreach (['Transactions', 'Customers', 'Services', 'Expenses'] as $index => $sheet) {
            $actual = array_map('strval', $response['valueRanges'][$index]['values'][0] ?? []);
            if ($actual !== self::SCHEMA[$sheet]) {
                throw new ApiError('Header kolom tab ' . $sheet . ' tidak sesuai; periksa hasil impor CSV sebelum mengganti data.', 409);
            }
        }
    }

    /** Finish the schema even if the first request was interrupted after Drive file creation. */
    private function initializeNewFile(string $id, string $tenantId, string $slug, array $tenant): void
    {
        $metadata = GoogleAccount::api('GET', $this->su($id) . '?fields=' . rawurlencode('sheets.properties.title'));
        $available = array_column(array_map(static fn($s) => $s['properties'] ?? [], $metadata['sheets'] ?? []), 'title');
        $requests = [];
        foreach (array_keys(self::SCHEMA) as $name) if (!in_array($name, $available, true)) $requests[] = ['addSheet' => ['properties' => ['title' => $name, 'gridProperties' => ['frozenRowCount' => 1]]]];
        if ($requests) GoogleAccount::api('POST', $this->su($id) . ':batchUpdate', ['requests' => $requests]);
        $metadataValues = [['key','value'], ['tenantId', $tenantId], ['slug', $slug],
            ['name', (string) ($tenant['name'] ?? $slug)], ['ownerUid', $tenantId],
            ['createdAt', gmdate('c')]];
        $writes = [];
        foreach (self::SCHEMA as $sheet => $cols) {
            $writes[] = ['range' => $sheet . '!A1', 'values' => $sheet === 'Meta' ? $metadataValues : [$cols]];
        }
        GoogleAccount::api('POST', $this->su($id) . '/values:batchUpdate',
            ['valueInputOption' => 'RAW', 'data' => $writes]);
    }

    /** Recover only a Drive file that this app itself tagged for the same tenant. */
    private function recoverOwnedInterruptedFile(string $id, string $tenantId, string $slug, array $tenant): bool
    {
        $file = GoogleAccount::api('GET', $this->du($id) . '?fields=' . rawurlencode('id,mimeType,trashed,appProperties'));
        $props = is_array($file['appProperties'] ?? null) ? $file['appProperties'] : [];
        if (($file['trashed'] ?? false) === true
            || ($file['mimeType'] ?? '') !== 'application/vnd.google-apps.spreadsheet'
            || ($props['ogiposTenantId'] ?? '') !== $tenantId
            || ($props['ogiposSlug'] ?? '') !== $slug) return false;

        $metadata = GoogleAccount::api('GET', $this->su($id) . '?fields=' . rawurlencode('sheets.properties.title'));
        $names = array_column(array_map(static fn($sheet) => $sheet['properties'] ?? [], $metadata['sheets'] ?? []), 'title');
        if (in_array('Meta', $names, true)) {
            $response = GoogleAccount::api('GET', $this->su($id) . '/values/' . rawurlencode('Meta!A1:B30'));
            foreach (($response['values'] ?? []) as $row) {
                if (in_array((string) ($row[0] ?? ''), ['tenantId', 'slug'], true)
                    && trim((string) ($row[1] ?? '')) !== '') return false;
            }
        }
        $this->initializeNewFile($id, $tenantId, $slug, $tenant);
        $this->checkMeta($id, $tenantId, $slug);
        return true;
    }

    public function provision(string $tenantId, array $tenant, string $boundId = ''): array
    {
        if (!preg_match('/^[A-Za-z0-9_-]{6,128}$/', $tenantId)) throw new ApiError('Tenant ID tidak valid.');
        $slug = Web::slug((string) ($tenant['slug'] ?? ''));
        $old = $boundId !== '' ? $boundId : (string) ($tenant['spreadsheetId'] ?? '');
        if ($old !== '') {
            try { $this->checkMeta($old, $tenantId, $slug); }
            catch (ApiError $error) {
                if (!$this->recoverOwnedInterruptedFile($old, $tenantId, $slug, $tenant)) throw $error;
            }
            return ['ok' => true, 'spreadsheetId' => $old,
                'spreadsheetUrl' => 'https://docs.google.com/spreadsheets/d/' . $this->sid($old) . '/edit', 'existing' => true];
        }
        $query = "trashed = false and mimeType = 'application/vnd.google-apps.spreadsheet' and appProperties has { key='ogiposTenantId' and value='" . $tenantId . "' }";
        $found = GoogleAccount::api('GET', $this->du() . '?q=' . rawurlencode($query) . '&fields=' . rawurlencode('files(id,name),nextPageToken') . '&pageSize=5');
        foreach (($found['files'] ?? []) as $file) {
            $candidate = (string) ($file['id'] ?? '');
            if ($candidate !== '') {
                try {
                    $this->checkMeta($candidate, $tenantId, $slug);
                } catch (ApiError $error) {
                    // Do not overwrite any legacy or foreign data. Only heal OUR OWN blank
                    // Drive-created file (found through private appProperties) lacking Meta.
                    $rows = [];
                    try {
                        $meta = GoogleAccount::api('GET', $this->su($candidate) . '/values/' . rawurlencode('Meta!A1:B30'));
                        $rows = $meta['values'] ?? [];
                    } catch (ApiError $metaError) {
                        // Meta tab may not exist if the initial process stopped after files.create.
                        $fileInfo = GoogleAccount::api('GET', $this->su($candidate) . '?fields=' . rawurlencode('sheets.properties.title'));
                        $names = array_column(array_map(static fn($sh) => $sh['properties'] ?? [], $fileInfo['sheets'] ?? []), 'title');
                        if (in_array('Meta', $names, true)) throw $metaError;
                    }
                    $map = [];
                    foreach ($rows as $row) if (count($row) > 1) $map[(string) $row[0]] = (string) $row[1];
                    if (isset($map['tenantId']) || isset($map['slug'])) throw $error;
                    $this->initializeNewFile($candidate, $tenantId, $slug, $tenant);
                }
                return ['ok' => true, 'spreadsheetId' => $candidate,
                    'spreadsheetUrl' => 'https://docs.google.com/spreadsheets/d/' . $this->sid($candidate) . '/edit', 'existing' => true];
            }
        }
        $folder = Config::get('OGIPOS_GOOGLE_FOLDER_ID');
        $attributes = [
            'name' => 'OGIPOS - ' . substr((string) ($tenant['name'] ?? $slug), 0, 75) . ' - ' . $slug,
            'mimeType' => 'application/vnd.google-apps.spreadsheet',
            'appProperties' => ['ogiposTenantId' => $tenantId, 'ogiposSlug' => $slug],
        ];
        if ($folder !== '') { $this->sid($folder); $attributes['parents'] = [$folder]; }
        $created = GoogleAccount::api('POST', $this->du() . '?fields=id,webViewLink', $attributes);
        $id = (string) ($created['id'] ?? ''); $this->sid($id);
        $this->initializeNewFile($id, $tenantId, $slug, $tenant);
        return ['ok' => true, 'spreadsheetId' => $id,
            'spreadsheetUrl' => 'https://docs.google.com/spreadsheets/d/' . $this->sid($id) . '/edit', 'existing' => false];
    }
    public function rows(string $id, string $name): array
    {
        $this->sheet($name);
        if (!isset($this->cache[$id])) {
            $ranges = [];
            foreach (['Transactions', 'Customers', 'Services', 'Expenses'] as $n) $ranges[] = 'ranges=' . rawurlencode($n . '!A:Z');
            $response = GoogleAccount::api('GET', $this->su($id) . '/values:batchGet?valueRenderOption=UNFORMATTED_VALUE&' . implode('&', $ranges));
            $all = [];
            foreach (['Transactions', 'Customers', 'Services', 'Expenses'] as $index => $n) {
                $values = $response['valueRanges'][$index]['values'] ?? [];
                $header = array_map('strval', array_shift($values) ?: []);
                if ($header !== self::SCHEMA[$n]) throw new ApiError('Kolom sheet ' . $n . ' tidak sesuai. Perlu migrasi terkontrol.', 409);
                $all[$n] = [];
                foreach ($values as $row) {
                    if (!is_array($row) || trim((string) ($row[0] ?? '')) === '') continue;
                    $object = [];
                    foreach ($header as $i => $col) $object[$col] = $row[$i] ?? '';
                    $all[$n][] = $object;
                }
            }
            $this->cache[$id] = $all;
        }
        return $this->cache[$id][$name];
    }
    private function clearCache(string $id): void { unset($this->cache[$id]); }
    public function write(string $id, string $range, array $rows): void
    {
        if ($range !== 'Meta!A2') throw new ApiError('Range Meta tidak diizinkan.');
        $current = GoogleAccount::api('GET', $this->su($id) . '/values/' . rawurlencode('Meta!A2:B20'));
        $meta = [];
        foreach ($current['values'] ?? [] as $r) if (count($r) > 1) $meta[(string) $r[0]] = (string) $r[1];
        foreach ($rows as $r) {
            if (!is_array($r) || count($r) !== 2 || !is_scalar($r[0]) || !is_scalar($r[1])) throw new ApiError('Metadata tidak valid.');
            if (in_array((string) $r[0], ['tenantId','slug','ownerUid'], true) && isset($meta[(string) $r[0]]) && $meta[(string) $r[0]] !== (string) $r[1]) {
                throw new ApiError('Identitas tenant di Spreadsheet tidak boleh diubah.', 409);
            }
        }
        GoogleAccount::api('PUT', $this->su($id) . '/values/' . rawurlencode('Meta!A2') . '?valueInputOption=RAW',
            ['values' => $rows]);
        $this->clearCache($id);
    }
    public function append(string $id, string $name, array $object): void
    {
        $this->sheet($name);
        if ($name === 'Meta') throw new ApiError('Append Meta ditolak.');
        GoogleAccount::api('POST', $this->su($id) . '/values/' . rawurlencode($name . '!A:T') . ':append?valueInputOption=RAW&insertDataOption=INSERT_ROWS',
            ['values' => $this->valueList($name, [$object])]);
        $this->clearCache($id);
    }
    private function rowPosition(string $id, string $name, string $target): int
    {
        $this->sheet($name);
        $response = GoogleAccount::api('GET', $this->su($id) . '/values/' . rawurlencode($name . '!A2:A'));
        foreach (($response['values'] ?? []) as $i => $row) if (($row[0] ?? '') === $target) return $i + 2;
        throw new ApiError('Baris ' . $name . ' tidak ditemukan.', 404);
    }
    public function updateById(string $id, string $name, string $key, string $target, array $changes): void
    {
        if ($key !== 'id' || $name === 'Meta') throw new ApiError('Update kolom tidak diizinkan.');
        $at = $this->rowPosition($id, $name, $target);
        $source = GoogleAccount::api('GET', $this->su($id) . '/values/' . rawurlencode($name . '!A' . $at . ':T' . $at));
        $values = $source['values'][0] ?? [];
        $before = array_combine(self::SCHEMA[$name], array_pad($values, count(self::SCHEMA[$name]), ''));
        foreach ($changes as $keyName => $value) {
            if (!in_array($keyName, self::SCHEMA[$name], true) || $keyName === 'id') throw new ApiError('Kolom perubahan tidak diizinkan.');
            $before[$keyName] = $value;
        }
        GoogleAccount::api('PUT', $this->su($id) . '/values/' . rawurlencode($name . '!A' . $at) . '?valueInputOption=RAW',
            ['values' => $this->valueList($name, [$before])]);
        $this->clearCache($id);
    }
    public function deleteById(string $id, string $name, string $target): void
    {
        if ($name === 'Meta') throw new ApiError('Tidak boleh menghapus Meta.');
        $index = $this->rowPosition($id, $name, $target) - 1;
        $info = GoogleAccount::api('GET', $this->su($id) . '?fields=' . rawurlencode('sheets.properties(sheetId,title)'));
        $numeric = null;
        foreach ($info['sheets'] ?? [] as $sheet) if (($sheet['properties']['title'] ?? '') === $name) $numeric = $sheet['properties']['sheetId'];
        if ($numeric === null) throw new ApiError('Sheet tidak ditemukan.', 404);
        GoogleAccount::api('POST', $this->su($id) . ':batchUpdate', ['requests' => [[
            'deleteDimension' => ['range' => ['sheetId' => $numeric, 'dimension' => 'ROWS', 'startIndex' => $index, 'endIndex' => $index + 1]]]]]);
        $this->clearCache($id);
    }
    public function replaceRows(string $id, string $name, array $objects): void
    {
        if ($name === 'Meta') throw new ApiError('Tidak boleh mengganti metadata.');
        $this->sheet($name);
        GoogleAccount::api('POST', $this->su($id) . '/values/' . rawurlencode($name . '!A2:Z') . ':clear', new \stdClass());
        if ($objects) GoogleAccount::api('PUT', $this->su($id) . '/values/' . rawurlencode($name . '!A2') . '?valueInputOption=RAW',
            ['values' => $this->valueList($name, $objects)]);
        $this->clearCache($id);
    }
    public function backup(string $id, string $tenantId, array $data): array
    {
        $this->sid($id);
        $name = 'OGIPOS BACKUP - ' . (string) ($data['slug'] ?? $tenantId) . ' - ' . gmdate('Y-m-d_H-i-s');
        $result = GoogleAccount::api('POST', $this->du($id) . '/copy?fields=id,name', ['name' => $name]);
        $backupId = (string) ($result['id'] ?? ''); $this->sid($backupId);
        return ['ok' => true, 'spreadsheetId' => $backupId,
            'spreadsheetUrl' => 'https://docs.google.com/spreadsheets/d/' . $backupId . '/edit',
            'message' => 'Salinan seluruh data dibuat di Google Drive pemilik tanpa email undangan.'];
    }
}
