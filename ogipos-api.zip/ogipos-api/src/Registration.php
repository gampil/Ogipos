<?php
declare(strict_types=1);
namespace Ogipos;

/** Registration writes trusted tenant registry on the PHP server, never from browser. */
final class Registration
{
    public function __construct(private readonly Store $store, private readonly Firebase $firebase) {}

    private static function label(mixed $value, string $label, int $limit): string
    {
        if (!is_string($value)) throw new ApiError($label . ' tidak valid.');
        $text = trim(preg_replace('/[\x00-\x1F\x7F]/u', ' ', $value) ?? '');
        if ($text === '' || strlen($text) > $limit) throw new ApiError($label . ' wajib diisi (maksimal ' . $limit . ' byte).');
        return $text;
    }

    /** Save the non-secret registration payload server-side so verification can finish on another device. */
    public function saveDraft(array $input): array
    {
        $user = $this->firebase->userInfo();
        $uid = (string) ($user['localId'] ?? '');
        $email = strtolower((string) ($user['email'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_-]{6,128}$/', $uid) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new ApiError('Akun Firebase tidak valid.', 401);
        }
        $business = self::label($input['laundryName'] ?? '', 'Nama laundry', 140);
        $asciiName = function_exists('iconv') ? (iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $business) ?: $business) : $business;
        $slug = Web::slug(rtrim(substr(trim(preg_replace('/[^a-z0-9]+/i', '-', strtolower($asciiName)) ?? '', '-'), 0, 30), '-'));
        if (isset($input['slug']) && $input['slug'] !== $slug) throw new ApiError('Alamat usaha harus mengikuti nama laundry.');
        $reserved = ['www','app','admin','api','mail','webmail','cpanel','ftp','daftar','register','signup','static','assets','support','help','sukses'];
        if (in_array($slug, $reserved, true)) throw new ApiError('Alamat subdomain dicadangkan sistem.', 409);
        $owner = self::label($input['ownerName'] ?? '', 'Nama pemilik', 100);
        $address = trim((string) ($input['address'] ?? ''));
        if (strlen($address) > 300) throw new ApiError('Alamat terlalu panjang.');
        $phone = preg_replace('/[^0-9]/', '', (string) ($input['phone'] ?? ''));
        if (strlen($phone) > 20) throw new ApiError('Telepon tidak valid.');
        $now = (int) (microtime(true) * 1000);
        $draft = ['ownerName' => $owner, 'laundryName' => $business, 'slug' => $slug,
            'phone' => $phone, 'address' => $address, 'email' => $email,
            'updatedAt' => $now, 'expiresAt' => $now + 7 * 86400000];
        $this->firebase->put('ogipos_server/registration_drafts/' . $uid, $draft);
        return ['ok' => true, 'saved' => true, 'expiresAt' => $draft['expiresAt']];
    }

    /** Return only the authenticated account's unexpired draft. */
    public function getDraft(): array
    {
        $user = $this->firebase->userInfo();
        $uid = (string) ($user['localId'] ?? '');
        $draft = $this->firebase->get('ogipos_server/registration_drafts/' . $uid);
        if (!$draft || (int) ($draft['expiresAt'] ?? 0) < (int) (microtime(true) * 1000)
            || strtolower((string) ($draft['email'] ?? '')) !== strtolower((string) ($user['email'] ?? ''))) {
            return ['ok' => true, 'draft' => null];
        }
        unset($draft['email'], $draft['updatedAt'], $draft['expiresAt']);
        return ['ok' => true, 'draft' => $draft];
    }

    public function register(array $input): array
    {
        $user = $this->firebase->userInfo();
        $uid = (string) ($user['localId'] ?? '');
        $email = strtolower((string) ($user['email'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_-]{6,128}$/', $uid) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new ApiError('Akun Firebase belum terverifikasi.', 401);
        }
        if (($user['emailVerified'] ?? false) !== true) {
            throw new ApiError('Verifikasi email Owner terlebih dahulu sebelum membuat akun usaha.', 409);
        }
        if (empty($input['laundryName']) || empty($input['ownerName'])) {
            $draft = $this->firebase->get('ogipos_server/registration_drafts/' . $uid);
            if (!$draft || (int) ($draft['expiresAt'] ?? 0) < (int) (microtime(true) * 1000)
                || strtolower((string) ($draft['email'] ?? '')) !== $email) {
                throw new ApiError('Data pendaftaran tidak ditemukan atau sudah kedaluwarsa. Silakan ulangi pendaftaran.', 404);
            }
            $input = array_merge($draft, $input);
        }
        $business = self::label($input['laundryName'] ?? '', 'Nama laundry', 140);
        $asciiName = function_exists('iconv') ? (iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $business) ?: $business) : $business;
        $derived = strtolower(trim($asciiName));
        $derived = trim(preg_replace('/[^a-z0-9]+/', '-', $derived) ?? '', '-');
        $derived = rtrim(substr($derived, 0, 30), '-');
        $slug = Web::slug($derived);
        if (isset($input['slug']) && $input['slug'] !== $slug) throw new ApiError('Alamat usaha harus mengikuti nama laundry.');
        $reserved = ['www','app','admin','api','mail','webmail','cpanel','ftp','daftar','register','signup','static','assets','support','help','sukses'];
        if (in_array($slug, $reserved, true)) throw new ApiError('Alamat subdomain dicadangkan sistem.', 409);
        $owner = self::label($input['ownerName'] ?? '', 'Nama pemilik', 100);
        $address = trim((string) ($input['address'] ?? ''));
        if (strlen($address) > 300) throw new ApiError('Alamat terlalu panjang.');
        $phone = preg_replace('/[^0-9]/', '', (string) ($input['phone'] ?? ''));
        if (strlen($phone) > 20) throw new ApiError('Telepon tidak valid.');
        // Validate access before issuing new tenant records.
        $this->store->legacyCutoffMs();
        $this->store->guardRate('tenant-signup-' . $uid, 8, 3600);

        return $this->store->locked('signup-' . $uid, function () use ($uid, $email, $slug, $owner, $business, $address, $phone): array {
            $existing = $this->firebase->get('users/' . $uid);
            if ($existing) {
                if (($existing['tenantId'] ?? '') === $uid && ($existing['role'] ?? '') === 'owner') {
                    $tenant = $this->firebase->get('tenants/' . $uid);
                    if (($tenant['slug'] ?? '') === $slug && ($tenant['ownerUid'] ?? '') === $uid) {
                        $this->firebase->patch('', ['ogipos_server/registration_drafts/' . $uid => null]);
                        return ['ok' => true, 'tenantId' => $uid, 'slug' => $slug,
                            'ownerEmail' => $email, 'trialExpired' => (int) ($tenant['trialExpired'] ?? 0), 'existing' => true];
                    }
                }
                throw new ApiError('Akun ini sudah terdaftar pada usaha lain.', 409);
            }
            $now = (int) (microtime(true) * 1000);
            $trialConfig = $this->firebase->get('ogipos_master/system/defaultTrial');
            $days = max(0, min(365, (float) ($trialConfig['days'] ?? $trialConfig['hari'] ?? 14)));
            $hours = max(0, min(720, (float) ($trialConfig['hours'] ?? $trialConfig['jam'] ?? 0)));
            $minutes = max(0, min(60000, (float) ($trialConfig['minutes'] ?? $trialConfig['menit'] ?? 0)));
            $trialMs = (int) (($days * 86400 + $hours * 3600 + $minutes * 60) * 1000);
            if ($trialMs <= 0) $trialMs = 14 * 86400000;
            $trialExpired = $now + $trialMs;
            $public = ['tenantId' => $uid, 'slug' => $slug, 'name' => $business, 'phone' => $phone,
                'address' => $address, 'status' => 'registering', 'package' => 'trial', 'lifetime' => false,
                'paymentRequired' => false, 'maintenance' => false, 'trialExpired' => $trialExpired,
                'createdAt' => $now, 'updatedAt' => $now, 'expiresAt' => $now + 300000];

            $claim = $this->firebase->cas('publicTenants/' . $slug, function (?array $current) use ($public, $uid, $now): array|false {
                if ($current === null || ($current['tenantId'] ?? '') === $uid && ($current['status'] ?? '') === 'registering') return $public;
                if (($current['status'] ?? '') === 'registering' && (int) ($current['expiresAt'] ?? 0) < $now) {
                    $former = (string) ($current['tenantId'] ?? '');
                    if (preg_match('/^[A-Za-z0-9_-]{6,128}$/', $former)) {
                        $tenant = $this->firebase->get('tenants/' . $former);
                        if (($tenant['slug'] ?? '') === $public['slug']) return false;
                    }
                    return $public;
                }
                return false;
            });
            if (!$claim['written'] || ($claim['value']['tenantId'] ?? '') !== $uid) throw new ApiError('Alamat subdomain sudah digunakan.', 409);

            $profile = ['tenantId' => $uid, 'name' => $owner, 'email' => $email, 'role' => 'owner', 'active' => true, 'createdAt' => $now];
            $tenant = ['ownerUid' => $uid, 'slug' => $slug, 'name' => $business, 'phone' => $phone,
                'address' => $address, 'receiptFooter' => 'Terima kasih atas kepercayaan Anda', 'receiptLogo' => '',
                'spreadsheetId' => '', 'spreadsheetUrl' => '', 'provisioningStatus' => 'pending',
                'status' => 'trial', 'package' => 'trial', 'lifetime' => false, 'maintenance' => false,
                'maintenanceMessage' => '', 'trialExpired' => $trialExpired, 'paymentRequired' => false,
                'createdAt' => $now, 'updatedAt' => $now];
            $master = ['tenantId' => $uid, 'tenantName' => $business, 'name' => $business,
                'domain' => $slug . '.' . Config::get('OGIPOS_BASE_DOMAIN', 'ogipos.com'), 'slug' => $slug,
                'ownerName' => $owner, 'ownerEmail' => $email, 'phone' => $phone, 'status' => 'trial',
                'package' => 'trial', 'lifetime' => false, 'maintenance' => false,
                'maintenanceMessage' => '', 'paymentRequired' => false, 'trialExpired' => $trialExpired,
                'createdAt' => $now, 'updatedAt' => $now, 'createdBy' => $uid];
            try {
                $this->firebase->patch('', [
                    'users/' . $uid => $profile,
                    'tenantMembers/' . $uid . '/' . $uid => $profile,
                    'tenants/' . $uid => $tenant,
                    'ogipos_master/tenants/' . $uid => $master,
                    'ogipos_master/logs/' . 'LOG' . strtoupper(bin2hex(random_bytes(9))) => [
                        'adminUid' => $uid, 'adminName' => $owner, 'action' => 'Tenant baru mendaftar',
                        'target' => $uid, 'tenantId' => $uid, 'timestamp' => $now],
                    'publicTenants/' . $slug . '/status' => 'trial',
                    'publicTenants/' . $slug . '/expiresAt' => null,
                    'publicTenants/' . $slug . '/updatedAt' => $now,
                ] + Notifications::jobPatch('trial-' . $uid, 'trial', $uid));
                Notifications::afterResponse($this->firebase, $this->store, 'trial-' . $uid);
            } catch (\Throwable $error) {
                // Release only our unfinished reservation. Never remove a committed tenant.
                try {
                    $this->firebase->cas('publicTenants/' . $slug, static fn(?array $r): array|false|null =>
                        ($r['tenantId'] ?? '') === $uid && ($r['status'] ?? '') === 'registering' ? null : false);
                } catch (\Throwable $ignored) { error_log('OGIPOS registration reservation cleanup failed.'); }
                throw $error;
            }
            $this->firebase->patch('', ['ogipos_server/registration_drafts/' . $uid => null]);
            return ['ok' => true, 'tenantId' => $uid, 'slug' => $slug, 'ownerEmail' => $email, 'trialExpired' => $trialExpired, 'existing' => false];
        });
    }
}
