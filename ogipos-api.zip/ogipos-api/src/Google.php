<?php
declare(strict_types=1);
namespace Ogipos;

/** Google OAuth access for the owner's real Google account. No service account or invites. */
final class GoogleAccount
{
    private static function directory(): string
    {
        $path = dirname(__DIR__) . '/storage';
        if (!is_dir($path) && !mkdir($path, 0700, true) && !is_dir($path)) {
            throw new ApiError('Folder privat Google belum dapat dibuat.', 503);
        }
        return $path;
    }
    private static function secretKey(): string
    {
        $key = Config::need('OGIPOS_ENCRYPTION_KEY');
        if (!preg_match('/^[0-9a-fA-F]{64}$/', $key)) throw new ApiError('OGIPOS_ENCRYPTION_KEY harus 64 karakter hex.', 503);
        return hex2bin($key);
    }
    private static function credentialsPath(): string { return self::directory() . '/google-token.enc'; }
    private static function tokenJson(string $url, array $form): array
    {
        $curl = curl_init($url);
        curl_setopt_array($curl, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 20, CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_POSTFIELDS => http_build_query($form, '', '&', PHP_QUERY_RFC3986)]);
        $body = curl_exec($curl); $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $err = curl_error($curl); curl_close($curl);
        $result = is_string($body) ? json_decode($body, true) : null;
        if ($status !== 200 || !is_array($result) || !isset($result['access_token'])) {
            error_log('OGIPOS OAuth token status=' . $status . ' curl=' . $err . ' error=' . substr((string) ($result['error'] ?? ''), 0, 100));
            throw new ApiError('Otorisasi Google gagal. Hubungkan ulang akun Google di panel admin.', 503);
        }
        return $result;
    }
    private static function oauthParams(): array
    {
        return ['client_id' => Config::need('OGIPOS_GOOGLE_CLIENT_ID'),
            'client_secret' => Config::need('OGIPOS_GOOGLE_CLIENT_SECRET'),
            'redirect_uri' => Config::need('OGIPOS_GOOGLE_REDIRECT_URI')];
    }
    public static function connectUrl(string $adminUid): string
    {
        $state = bin2hex(random_bytes(24));
        $payload = json_encode(['admin' => $adminUid, 'expires' => time() + 600], JSON_THROW_ON_ERROR);
        $file = self::directory() . '/oauth-' . $state . '.json';
        if (file_put_contents($file, $payload, LOCK_EX) === false) throw new ApiError('Tidak dapat menyimpan OAuth state.', 503);
        chmod($file, 0600);
        $params = [
            'client_id' => Config::need('OGIPOS_GOOGLE_CLIENT_ID'),
            'redirect_uri' => Config::need('OGIPOS_GOOGLE_REDIRECT_URI'),
            'scope' => 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email',
            'response_type' => 'code', 'access_type' => 'offline', 'prompt' => 'consent',
            'include_granted_scopes' => 'true', 'state' => $state,
        ];
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }
    public static function complete(array $query): void
    {
        $state = (string) ($query['state'] ?? '');
        if (!preg_match('/^[a-f0-9]{48}$/', $state)) throw new ApiError('OAuth state tidak valid.', 400);
        $file = self::directory() . '/oauth-' . $state . '.json';
        $raw = @file_get_contents($file);
        if ($raw === false) throw new ApiError('Sesi koneksi Google sudah tidak berlaku.', 403);
        unlink($file); // One-time use, including failed callbacks.
        $record = json_decode($raw, true);
        if (!is_array($record) || (int) ($record['expires'] ?? 0) < time()) throw new ApiError('Sesi Google kedaluwarsa.', 403);
        if (!empty($query['error'])) throw new ApiError('Izin Google dibatalkan: ' . substr((string) $query['error'], 0, 80), 400);
        $code = (string) ($query['code'] ?? '');
        if ($code === '' || strlen($code) > 2048) throw new ApiError('Kode Google tidak valid.', 400);
        $token = self::tokenJson('https://oauth2.googleapis.com/token', self::oauthParams() + [
            'grant_type' => 'authorization_code', 'code' => $code]);
        $refresh = (string) ($token['refresh_token'] ?? '');
        if ($refresh === '') throw new ApiError('Refresh token tidak diberikan. Cabut izin aplikasi di akun Google lalu hubungkan ulang.', 400);
        $me = Web::request('GET', 'https://www.googleapis.com/oauth2/v3/userinfo', null,
            ['Authorization: Bearer ' . $token['access_token']]);
        $email = strtolower((string) ($me['email'] ?? ''));
        $required = strtolower(Config::need('OGIPOS_GOOGLE_OWNER_EMAIL'));
        if ($email === '' || !hash_equals($required, $email) || !($me['email_verified'] ?? false)) {
            throw new ApiError('Akun Google tidak cocok dengan OGIPOS_GOOGLE_OWNER_EMAIL.', 403);
        }
        $plain = json_encode(['refresh_token' => $refresh, 'email' => $email], JSON_THROW_ON_ERROR);
        $iv = random_bytes(12); $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', self::secretKey(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) throw new ApiError('Enkripsi akses Google gagal.', 500);
        $destination = self::credentialsPath();
        $temp = self::directory() . '/google-token-' . bin2hex(random_bytes(6)) . '.tmp';
        if (file_put_contents($temp, base64_encode($iv . $tag . $cipher), LOCK_EX) === false) throw new ApiError('Tidak dapat menyimpan token Google.', 503);
        chmod($temp, 0600);
        if (!rename($temp, $destination)) { unlink($temp); throw new ApiError('Tidak dapat menyimpan koneksi Google.', 503); }
        @unlink(self::directory() . '/google-access.enc');
    }
    public static function status(): array
    {
        try {
            $record = self::stored();
        } catch (ApiError $error) {
            return ['ok' => true, 'connected' => false, 'operational' => false,
                'email' => '', 'provider' => 'Google OAuth PHP', 'diagnostic' => $error->getMessage()];
        }
        try {
            self::driveReady();
            return ['ok' => true, 'connected' => true, 'operational' => true,
                'email' => (string) ($record['email'] ?? ''), 'provider' => 'Google OAuth PHP'];
        } catch (ApiError $error) {
            return ['ok' => true, 'connected' => true, 'operational' => false,
                'email' => (string) ($record['email'] ?? ''), 'provider' => 'Google OAuth PHP',
                'diagnostic' => $error->getMessage()];
        }
    }
    public static function driveReady(): void
    {
        // Cheap, read-only Drive v3 call also detects disabled API (token alone cannot).
        self::api('GET', 'https://www.googleapis.com/drive/v3/files?pageSize=1&fields=files(id)');
    }
    private static function stored(): array
    {
        $raw = @file_get_contents(self::credentialsPath());
        if ($raw === false) throw new ApiError('Google Drive belum terhubung. Hubungkan di panel admin.', 503);
        $binary = base64_decode($raw, true);
        if ($binary === false || strlen($binary) < 30) throw new ApiError('Token Google rusak.', 503);
        $plain = openssl_decrypt(substr($binary, 28), 'aes-256-gcm', self::secretKey(), OPENSSL_RAW_DATA,
            substr($binary, 0, 12), substr($binary, 12, 16));
        $stored = $plain !== false ? json_decode($plain, true) : null;
        if (!is_array($stored) || empty($stored['refresh_token']) || empty($stored['email'])) {
            throw new ApiError('Token Google tidak dapat dibaca.', 503);
        }
        return $stored;
    }
    public static function accessToken(): string
    {
        static $access = null;
        if ($access !== null) return $access;
        $path = self::directory() . '/google-access.enc';
        $existing = @file_get_contents($path);
        if ($existing !== false) {
            $data = base64_decode($existing, true);
            if ($data !== false && strlen($data) > 30) {
                $decoded = openssl_decrypt(substr($data, 28), 'aes-256-gcm', self::secretKey(), OPENSSL_RAW_DATA,
                    substr($data, 0, 12), substr($data, 12, 16));
                $cached = $decoded !== false ? json_decode($decoded, true) : null;
                if (is_array($cached) && (int) ($cached['expires'] ?? 0) > time() + 90 && !empty($cached['token'])) {
                    $access = (string) $cached['token'];
                    return $access;
                }
            }
        }
        $record = self::stored();
        $token = self::tokenJson('https://oauth2.googleapis.com/token', self::oauthParams() + [
            'grant_type' => 'refresh_token', 'refresh_token' => $record['refresh_token']]);
        $access = (string) $token['access_token'];
        $iv = random_bytes(12); $tag = '';
        $plain = json_encode(['token' => $access, 'expires' => time() + max(120, (int) ($token['expires_in'] ?? 3600))], JSON_THROW_ON_ERROR);
        $encrypted = openssl_encrypt($plain, 'aes-256-gcm', self::secretKey(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($encrypted !== false) { @file_put_contents($path, base64_encode($iv . $tag . $encrypted), LOCK_EX); @chmod($path, 0600); }
        return $access;
    }
    public static function api(string $method, string $url, mixed $payload = null, array $headers = []): array
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ((string) parse_url($url, PHP_URL_SCHEME) !== 'https' || !in_array($host,
            ['sheets.googleapis.com', 'www.googleapis.com'], true)) throw new ApiError('Google API URL tidak valid.', 500);
        $headers[] = 'Authorization: Bearer ' . self::accessToken();
        $headers[] = 'Accept: application/json';
        if ($payload !== null) $headers[] = 'Content-Type: application/json';
        $curl = curl_init($url);
        curl_setopt_array($curl, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 22, CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTPHEADER => $headers]);
        if ($payload !== null) curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        $raw = curl_exec($curl); $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $err = curl_error($curl); curl_close($curl);
        $body = is_string($raw) ? json_decode($raw, true) : null;
        if ($status < 200 || $status >= 300 || !is_array($body)) {
            $googleError = is_array($body) ? (string) ($body['error']['message'] ?? '') : '';
            error_log('OGIPOS Google API status=' . $status . ' host=' . $host . ' error=' . substr($googleError ?: $err, 0, 220));
            // OAuth can be connected while an API is disabled in Google Cloud Console.
            // This is a permanent configuration failure: never retry or create a new file.
            if ($status === 403 && preg_match('/(has not been used|disabled|SERVICE_DISABLED|accessNotConfigured|not enabled)/i', $googleError)) {
                $service = $host === 'sheets.googleapis.com' ? 'Google Sheets API' : 'Google Drive API';
                throw new ApiError($service . ' belum aktif di Google Cloud Project yang dipakai OAuth OGIPOS. Aktifkan API tersebut di Google Cloud Console.', 503, $status);
            }
            if ($status === 403 && preg_match('/(insufficient|permission|scope|forbidden)/i', $googleError)) {
                throw new ApiError('Akses Google ditolak (403). Periksa izin OAuth dan kepemilikan file Google Drive.', 503, $status);
            }
            throw new ApiError('Google Cloud Database gagal (' . $status . '). Periksa izin OAuth dan log server.', 502, $status);
        }
        return $body;
    }
}
