<?php
declare(strict_types=1);
namespace Ogipos;

/** Durable transactional outbox: API queues; the CLI worker handles SMTP. */
final class Notifications
{
    private static array $scheduled = [];

    public static function jobPatch(string $id, string $type, string $tenantId, array $data = []): array
    {
        if (!preg_match('/^[A-Za-z0-9_-]{1,160}$/', $id) || !in_array($type, ['trial', 'verified', 'lifetime'], true))
            throw new ApiError('Job notifikasi tidak valid.');
        return ['ogipos_server/mail_queue/' . $id => ['id' => $id, 'type' => $type, 'tenantId' => $tenantId,
            'data' => $data, 'status' => 'pending', 'attempts' => 0, 'nextAttemptAt' => time(), 'createdAt' => time()]];
    }

    public function __construct(private readonly Firebase $firebase, private readonly Store $store) {}

    /**
     * Try the exact queued email after the JSON response is finished. Cron remains the
     * durable retry path, while successful payments no longer wait for the next cron tick.
     */
    public static function afterResponse(Firebase $firebase, Store $store, string $id): void
    {
        // On Apache/LSAPI there is no reliable way to detach work from the HTTP
        // response; the authenticated invoice-email endpoint and cron handle it.
        if (!function_exists('fastcgi_finish_request')) return;
        if (isset(self::$scheduled[$id])) return;
        self::$scheduled[$id] = true;
        register_shutdown_function(static function () use ($firebase, $store, $id): void {
            @fastcgi_finish_request();
            @ignore_user_abort(true);
            try { (new self($firebase, $store))->processJob($id); }
            catch (\Throwable $error) { error_log('OGIPOS deferred mail remains queued: ' . $id); }
        });
    }

    public function confirmVerifiedAccount(): array
    {
        $user = $this->firebase->userInfo(); $uid = (string) $user['localId'];
        if (($user['emailVerified'] ?? false) !== true) throw new ApiError('Email akun belum diverifikasi.', 409);
        [$ownerId] = $this->firebase->owner();
        if ($ownerId !== $uid) throw new ApiError('Akun Owner tidak cocok.', 403);
        return $this->store->locked('account-verification-' . $uid, function () use ($uid): array {
            if (!empty($this->firebase->get('users/' . $uid)['verifiedEmailNotifiedAt'])) {
                self::afterResponse($this->firebase, $this->store, 'verified-' . $uid);
                return ['ok' => true, 'existing' => true];
            }
            $this->firebase->patch('', ['users/' . $uid . '/verifiedEmailNotifiedAt' => (int) (microtime(true) * 1000)]
                + self::jobPatch('verified-' . $uid, 'verified', $uid));
            self::afterResponse($this->firebase, $this->store, 'verified-' . $uid);
            return ['ok' => true];
        });
    }

    public function process(int $limit = 15): array
    {
        if (!SmtpMail::configured()) return ['sent' => 0, 'pending' => true, 'reason' => 'SMTP belum dikonfigurasi.'];
        $queue = $this->firebase->get('ogipos_server/mail_queue'); $sent = 0; $failed = 0; $handled = 0;
        foreach ($queue as $id => $job) {
            if ($handled >= $limit) break;
            if (!is_array($job) || ($job['status'] ?? '') === 'sent' || ($job['status'] ?? '') === 'failed'
                || (int) ($job['nextAttemptAt'] ?? 0) > time()) continue;
            $handled++;
            try { $status = $this->processJob((string) $id); }
            catch (\Throwable $error) { $status = 'pending'; error_log('OGIPOS mail worker could not inspect job ' . $id); }
            if ($status === 'sent') $sent++;
            elseif ($status === 'pending' || $status === 'failed') $failed++;
        }
        return ['sent' => $sent, 'deferred' => $failed];
    }

    /** Process one idempotent outbox item; returns sent, pending, failed, skipped, or unconfigured. */
    public function processJob(string $id): string
    {
        if (!preg_match('/^[A-Za-z0-9_-]{1,160}$/', $id)) return 'skipped';
        if (!SmtpMail::configured()) return 'unconfigured';
        $path = 'ogipos_server/mail_queue/' . $id;
        $job = $this->firebase->get($path);
        if (!$job) return 'skipped';
        $status = (string) ($job['status'] ?? 'pending');
        if (in_array($status, ['sent', 'failed'], true)) return $status;
        if ((int) ($job['nextAttemptAt'] ?? 0) > time()) return 'skipped';
        try {
            $delivered = false;
            $this->store->locked('mail-' . $id, function () use ($id, $path, &$delivered): void {
                $job = $this->firebase->get($path);
                if (!$job || in_array(($job['status'] ?? ''), ['sent', 'failed'], true)
                    || (int) ($job['nextAttemptAt'] ?? 0) > time()) return;
                $uid = (string) ($job['tenantId'] ?? '');
                $owner = $this->firebase->get('users/' . $uid);
                $tenant = $this->firebase->get('tenants/' . $uid);
                if (($owner['role'] ?? '') !== 'owner' || ($tenant['ownerUid'] ?? '') !== $uid)
                    throw new ApiError('Penerima notifikasi tidak sesuai.', 409);
                $to = (string) ($owner['email'] ?? '');
                if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new ApiError('Email notifikasi tidak valid.');
                [$subject, $html, $attachment] = $this->template($job, $tenant, $owner);
                (new SmtpMail())->send($to, $subject, $html, $attachment, $id);
                $this->firebase->patch($path, ['status' => 'sent', 'sentAt' => time(),
                    'lastError' => null, 'nextAttemptAt' => null]);
                $delivered = true;
            });
            return $delivered ? 'sent' : 'skipped';
        } catch (ApiError $error) {
            // Another request already owns the delivery lock; leave the queue untouched.
            if ($error->status === 409 && $error->getMessage() === 'Sedang diproses. Coba beberapa saat lagi.') return 'skipped';
            return $this->defer($path, $job, $id);
        } catch (\Throwable $error) {
            return $this->defer($path, $job, $id);
        }
    }

    private function defer(string $path, array $job, string $id): string
    {
        $current = $this->firebase->get($path);
        if (($current['status'] ?? '') === 'sent') return 'sent';
        $attempts = (int) ($current['attempts'] ?? $job['attempts'] ?? 0) + 1;
        $status = $attempts >= 8 ? 'failed' : 'pending';
        $this->firebase->patch($path, ['status' => $status, 'attempts' => $attempts,
            'nextAttemptAt' => time() + min(21600, 60 * (2 ** $attempts)),
            'lastError' => 'Pengiriman email tertunda. Periksa koneksi/konfigurasi SMTP.']);
        error_log('OGIPOS mail delivery pending for job ' . $id);
        return $status;
    }

    private function template(array $job, array $tenant, array $owner): array
    {
        $escape = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $name = $escape((string) ($owner['name'] ?? 'Owner')); $business = $escape((string) ($tenant['name'] ?? 'Laundry Anda'));
        $url = 'https://' . Web::slug((string) $tenant['slug']) . '.' . Config::get('OGIPOS_BASE_DOMAIN', 'ogipos.com');
        $type = $job['type']; $attachment = null;
        if ($type === 'trial') {
            $subject = 'Trial OGIPOS Anda sudah aktif'; $title = 'Selamat datang di OGIPOS';
            $until = (new \DateTimeImmutable('@' . (int) floor(((int) $tenant['trialExpired']) / 1000)))->setTimezone(new \DateTimeZone('Asia/Jakarta'))->format('d/m/Y H:i') . ' WIB';
            $copy = "Akun usaha <strong>$business</strong> sudah aktif dalam masa trial sampai <strong>" . $escape($until)
                . '</strong>. Email Owner telah terverifikasi dan Cloud Database disiapkan otomatis ketika Anda masuk.';
        } elseif ($type === 'verified') {
            $subject = 'Email akun OGIPOS berhasil diverifikasi'; $title = 'Akun Anda sudah terverifikasi';
            $copy = "Email akun Owner untuk <strong>$business</strong> berhasil diverifikasi. Anda dapat melanjutkan pengelolaan usaha dan keamanan akun.";
        } else {
            $invoice = $this->store->invoice((string) ($job['data']['orderId'] ?? ''));
            if (!$invoice || $invoice['status'] !== 'success' || $invoice['tenant_id'] !== $job['tenantId'])
                throw new ApiError('Invoice email belum terverifikasi.', 409);
            $subject = 'Pembayaran Berhasil | OGIPOS Laundry - Invoice ' . $invoice['order_id']; $title = 'Pembayaran Berhasil, Lifetime Aktif';
            $copy = "Pembayaran untuk <strong>$business</strong> sudah terverifikasi. Paket Lifetime aktif dengan sekali bayar. Total pembayaran <strong>Rp "
                . number_format((int) $invoice['amount'], 0, ',', '.') . '</strong>. PDF invoice resmi pembayaran OGIPOS dilampirkan pada email ini.';
            $attachment = ['name' => 'Invoice-' . $invoice['order_id'] . '.pdf', 'bytes' => InvoicePdf::render($invoice, $owner)];
        }
        $html = '<!doctype html><html lang="id"><body style="margin:0;background:#f4f7f8;color:#163338;font-family:Arial,sans-serif"><div style="max-width:600px;margin:32px auto;background:#fff;border:1px solid #dde6e7;border-radius:12px;overflow:hidden"><div style="padding:28px 32px;background:#087f79;color:#fff;font-size:22px;font-weight:bold">OGIPOS <span style="font-size:12px;font-weight:normal">LAUNDRY</span></div><div style="padding:32px"><h1 style="font-size:24px;margin:0 0 20px">' . $title . '</h1><p>Halo ' . $name . ',</p><p style="line-height:1.8">' . $copy . '</p><p style="margin:28px 0"><a style="display:inline-block;padding:14px 22px;background:#087f79;color:#fff;border-radius:8px;text-decoration:none" href="' . $escape($url) . '">Buka usaha saya</a></p><p style="font-size:12px;color:#597479;line-height:1.8">Email ini adalah notifikasi akun OGIPOS. Jangan membagikan password maupun kode verifikasi Anda.</p></div></div></body></html>';
        return [$subject, $html, $attachment];
    }
}

/** SMTP AUTH over verified TLS; no credentials or SMTP transcript are logged. */
final class SmtpMail
{
    private $socket;
    public static function configured(): bool
    {
        return Config::get('OGIPOS_SMTP_HOST') !== '' && Config::get('OGIPOS_MAIL_FROM') !== ''
            && Config::get('OGIPOS_SMTP_USER') !== '' && Config::get('OGIPOS_SMTP_PASSWORD') !== '';
    }
    private function reply(array $expected): void
    {
        $line = ''; $count = 0;
        do {
            $line = fgets($this->socket, 2048);
            if ($line === false || ++$count > 100) throw new ApiError('SMTP tidak merespons.', 503);
        } while (isset($line[3]) && $line[3] === '-');
        if (!in_array((int) substr($line, 0, 3), $expected, true)) throw new ApiError('SMTP menolak pengiriman.', 503);
    }
    private function command(string $line, array $expected): void { $this->write($line . "\r\n"); $this->reply($expected); }
    private function write(string $data): void
    {
        $length = strlen($data); $offset = 0;
        while ($offset < $length) { $n = fwrite($this->socket, substr($data, $offset)); if (!$n) throw new ApiError('SMTP terputus.', 503); $offset += $n; }
    }
    public function send(string $to, string $subject, string $html, ?array $attachment, string $jobId): void
    {
        $host = Config::need('OGIPOS_SMTP_HOST'); $port = (int) Config::get('OGIPOS_SMTP_PORT', '587');
        $mode = Config::get('OGIPOS_SMTP_SECURITY', 'starttls'); $from = Config::need('OGIPOS_MAIL_FROM');
        if (!preg_match('/^[A-Za-z0-9.-]{1,253}$/', $host) || !filter_var($from, FILTER_VALIDATE_EMAIL)
            || !filter_var($to, FILTER_VALIDATE_EMAIL) || preg_match('/[\r\n]/', $to . $from . $subject)
            || !in_array($mode, ['starttls', 'ssl'], true) || !in_array($port, [465, 587, 2525], true))
            throw new ApiError('Konfigurasi SMTP tidak valid.', 503);
        $context = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host]]);
        $this->socket = stream_socket_client(($mode === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $errno, $error, 15, STREAM_CLIENT_CONNECT, $context);
        if ($this->socket === false) throw new ApiError('SMTP belum dapat dihubungi.', 503);
        stream_set_timeout($this->socket, 15);
        try {
            $this->reply([220]); $this->command('EHLO ogipos.com', [250]);
            if ($mode === 'starttls') {
                $this->command('STARTTLS', [220]);
                if (stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) throw new ApiError('TLS SMTP gagal.', 503);
                $this->command('EHLO ogipos.com', [250]);
            }
            $this->command('AUTH LOGIN', [334]); $this->command(base64_encode(Config::need('OGIPOS_SMTP_USER')), [334]);
            $this->command(base64_encode(Config::need('OGIPOS_SMTP_PASSWORD')), [235]);
            $this->command('MAIL FROM:<' . $from . '>', [250]); $this->command('RCPT TO:<' . $to . '>', [250, 251]);
            $this->command('DATA', [354]);
            $boundary = 'ogipos_' . bin2hex(random_bytes(12));
            $message = 'Date: ' . gmdate('D, d M Y H:i:s') . " +0000\r\nFrom: OGIPOS Laundry <" . $from . ">\r\nTo: <" . $to
                . ">\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMessage-ID: <" . hash('sha256', $jobId) . '@' . substr(strrchr($from, '@'), 1)
                . ">\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"" . $boundary . "\"\r\n\r\n--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                . chunk_split(base64_encode($html));
            if ($attachment !== null) {
                $filename = preg_replace('/[^A-Za-z0-9._-]/', '', (string) $attachment['name']);
                $message .= "--$boundary\r\nContent-Type: application/pdf; name=\"$filename\"\r\nContent-Disposition: attachment; filename=\"$filename\"\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($attachment['bytes']));
            }
            $message .= "--$boundary--\r\n";
            $this->write(preg_replace('/(?m)^\./', '..', $message) . ".\r\n"); $this->reply([250]);
            // DATA 250 already confirms acceptance. A failed QUIT must not resend this email.
            try { $this->command('QUIT', [221]); } catch (\Throwable $ignored) {}
        } finally { fclose($this->socket); }
    }
}
