<?php
declare(strict_types=1);
namespace Ogipos;

/** Small deterministic PDF invoice, with no network requests or runtime dependencies. */
final class InvoicePdf
{
    public static function render(array $invoice, array $owner = []): string
    {
        if (($invoice['status'] ?? '') !== 'success') throw new ApiError('Invoice belum lunas.', 409);
        $escape = static function (string $text): string {
            $text = preg_replace('/[\x00-\x1f\x7f]/', ' ', $text) ?? '';
            $encoded = function_exists('iconv') ? iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text) : preg_replace('/[^\x20-\x7e]/', '?', $text);
            return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], (string) $encoded);
        };
        $stream = '';
        $text = static function (float $x, float $y, float $size, string $value, bool $bold = false, string $color = '0.08 0.19 0.21') use (&$stream, $escape): void {
            $stream .= "$color rg BT /" . ($bold ? 'F2' : 'F1') . " $size Tf 1 0 0 1 $x $y Tm (" . $escape($value) . ") Tj ET\n";
        };
        $money = static fn(int $amount): string => 'Rp ' . number_format($amount, 0, ',', '.');
        $when = (new \DateTimeImmutable('@' . (int) floor(((int) ($invoice['paid_at'] ?? $invoice['created_at'])) / 1000)))->setTimezone(new \DateTimeZone('Asia/Jakarta'))->format('d/m/Y H:i') . ' WIB';
        $stream .= "0.03 0.50 0.47 rg 0 726 595 116 re f\n";
        $brandPath = dirname(__DIR__) . '/assets/images/ogipos-logo.jpg';
        $brandBytes = is_file($brandPath) ? @file_get_contents($brandPath) : false;
        $brandInfo = $brandBytes !== false ? @getimagesize($brandPath) : false;
        $brandOk = is_array($brandInfo) && ($brandInfo['mime'] ?? '') === 'image/jpeg'
            && $brandInfo[0] > 0 && $brandInfo[1] > 0 && $brandInfo[0] < 4000 && $brandInfo[1] < 4000;
        if ($brandOk) {
            // White-backed original OGIPOS logo; embedded locally without networking.
            $stream .= "q 178 0 0 62 44 746 cm /Im1 Do Q\n";
        } else {
            $text(44, 786, 25, 'OGIPOS', true, '1 1 1');
            $text(44, 761, 11, 'Laundry POS | Lifetime', false, '1 1 1');
        }
        $text(414, 780, 19, 'INVOICE', true, '1 1 1');
        $text(44, 692, 12, 'BUKTI PEMBAYARAN TERVERIFIKASI', true);
        $text(44, 664, 10, 'No. invoice: ' . $invoice['order_id']);
        $text(44, 644, 10, 'Tanggal pembayaran: ' . $when);
        $text(44, 602, 10, 'DITERBITKAN UNTUK', true);
        $name = (string) ($invoice['tenant_name'] ?? $invoice['slug']);
        foreach (str_split(substr($name, 0, 140), 60) as $i => $line) $text(44, 580 - $i * 16, 12, $line, true);
        $text(44, 531, 10, substr((string) ($owner['name'] ?? ''), 0, 70));
        $text(44, 513, 10, substr((string) ($owner['email'] ?? ''), 0, 85));
        $text(44, 491, 10, $invoice['slug'] . '.' . Config::get('OGIPOS_BASE_DOMAIN', 'ogipos.com'));
        $stream .= "0.94 0.97 0.96 rg 44 422 507 38 re f\n";
        $text(58, 437, 10, 'RINCIAN', true); $text(438, 437, 10, 'NOMINAL', true);
        $package = (int) ($invoice['package_amount'] ?? $invoice['amount']);
        $total = (int) $invoice['amount'];
        $text(58, 393, 12, 'Aktivasi OGIPOS Lifetime'); $text(434, 393, 12, $money($package), true);
        $text(58, 370, 10, 'Akses sekali bayar untuk usaha ini');
        $text(58, 336, 11, 'Biaya bayar / kode unik'); $text(434, 336, 11, $money($total - $package));
        $stream .= "0.82 0.89 0.88 RG 44 310 m 551 310 l S\n";
        $text(58, 281, 13, 'TOTAL DIBAYAR', true); $text(414, 281, 16, $money($total), true, '0.03 0.50 0.47');
        $text(58, 239, 13, 'LUNAS', true, '0.03 0.50 0.47');
        $text(58, 216, 10, 'Metode: QRIS');
        $text(58, 195, 9, 'Referensi pembayaran: ' . (string) ($invoice['gateway_order_id'] ?? $invoice['order_id']));
        $text(44, 131, 10, 'Terima kasih. Pembayaran telah diverifikasi.');
        $text(44, 112, 9, 'Simpan invoice ini sebagai bukti aktivasi Lifetime usaha Anda.');
        $text(44, 62, 8, 'Dokumen bukti pembayaran layanan OGIPOS. Bukan faktur pajak.');
        $objects = [
            '<< /Type /Catalog /Pages 2 0 R >>',
            '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
            '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> '
                . ($brandOk ? '/XObject << /Im1 7 0 R >> ' : '')
                . '>> /Contents 6 0 R >>',
            '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
            '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
            '<< /Length ' . strlen($stream) . ">>\nstream\n" . $stream . "endstream",
        ];
        if ($brandOk) {
            $objects[] = '<< /Type /XObject /Subtype /Image /Width ' . (int) $brandInfo[0]
                . ' /Height ' . (int) $brandInfo[1]
                . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '
                . strlen($brandBytes) . " >>\nstream\n" . $brandBytes . "\nendstream";
        }
        $pdf = "%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"; $offsets = [0];
        foreach ($objects as $i => $object) { $offsets[] = strlen($pdf); $pdf .= ($i + 1) . " 0 obj\n$object\nendobj\n"; }
        $objectCount = count($objects) + 1;
        $xref = strlen($pdf); $pdf .= "xref\n0 $objectCount\n0000000000 65535 f \n";
        foreach (array_slice($offsets, 1) as $offset) $pdf .= sprintf("%010d 00000 n \n", $offset);
        return $pdf . "trailer\n<< /Size $objectCount /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
    }
}
