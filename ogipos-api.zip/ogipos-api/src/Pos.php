<?php
declare(strict_types=1);

namespace Ogipos;

final class Pos
{
    public function __construct(
        private readonly Store $store,
        private readonly Firebase $firebase,
    ) {
    }

    /** Owner-only cloud diagnostic: no tokens or sheet identifiers are returned. */
    public function diagnose(): array
    {
        [$ownerUid] = $this->firebase->owner();
        $tenant = $this->firebase->get('tenants/' . $ownerUid);
        $slug = Web::slug((string) ($tenant['slug'] ?? ''));
        $public = $this->firebase->get('publicTenants/' . $slug);
        if (($tenant['ownerUid'] ?? '') !== $ownerUid || ($public['tenantId'] ?? '') !== $ownerUid) {
            throw new ApiError('Data tenant tidak sesuai dengan akun Owner.', 403);
        }
        $sheetId = (string) ($tenant['spreadsheetId'] ?? '');
        $binding = $this->firebase->get('ogipos_server/tenant_sheets/' . $ownerUid);
        $boundId = (string) ($binding['spreadsheetId'] ?? '');
        $bindingMatches = $sheetId !== '' && $sheetId === $boundId && ($binding['slug'] ?? '') === $slug;
        $google = GoogleAccount::status();
        $metaVerified = false;
        $schemaValid = false;
        $diagnostic = '';
        if ($sheetId === '') $diagnostic = 'Spreadsheet tenant belum terdaftar. Jalankan Pulihkan Cloud Database.';
        elseif (!$bindingMatches) $diagnostic = 'Binding tenant belum cocok. Jalankan Pulihkan Cloud Database sebagai Owner.';
        if ($sheetId !== '' && ($google['operational'] ?? false) === true) {
            try {
                $sheets = new TenantSheets($this->store);
                $sheets->verifyOwnership($sheetId, $ownerUid, $slug);
                $metaVerified = true;
                $sheets->verifySchema($sheetId);
                $schemaValid = true;
            } catch (ApiError $e) { $diagnostic = $e->getMessage(); }
        } elseif (($google['operational'] ?? false) !== true) {
            $diagnostic = (string) ($google['diagnostic'] ?? 'Koneksi Google API tidak aktif.');
        }
        return ['ok' => true, 'tenantRegistered' => $sheetId !== '',
            'bindingMatches' => $bindingMatches, 'metaVerified' => $metaVerified, 'schemaValid' => $schemaValid,
            'googleConnected' => (bool) ($google['connected'] ?? false),
            'googleOperational' => (bool) ($google['operational'] ?? false),
            'message' => $diagnostic ?: 'Cloud Database terverifikasi di akun Owner.'];
    }

    public function provision(): array
    {
        [$uid] = $this->firebase->owner();
        return $this->store->locked('sheet-' . $uid, function () use ($uid): array {
            $tenant = $this->firebase->get('tenants/' . $uid);
            $slug = Web::slug((string) ($tenant['slug'] ?? ''));
            $public = $this->firebase->get('publicTenants/' . $slug);
            if (($tenant['ownerUid'] ?? '') !== $uid || ($public['tenantId'] ?? '') !== $uid) {
                throw new ApiError('Identitas tenant dan subdomain tidak cocok.', 403);
            }
            try {
                $binding = $this->firebase->get('ogipos_server/tenant_sheets/' . $uid);
                $boundId = (string) ($binding['spreadsheetId'] ?? '');
                if ($boundId !== '' && ($binding['slug'] ?? '') !== $slug) {
                    throw new ApiError('Binding Spreadsheet tenant tidak cocok.', 409);
                }
                if ($boundId === '' && (string) ($tenant['spreadsheetId'] ?? '') === '') {
                    $cutoff = $this->store->legacyCutoffMs();
                    if ($cutoff <= 0 || (int) ($tenant['createdAt'] ?? 0) < $cutoff) {
                        throw new ApiError('Tenant lama perlu dipetakan ke Spreadsheet aslinya sebelum provisioning.', 409);
                    }
                }
                $tenant['ownerEmail'] = (string) ($this->firebase->get('users/' . $uid)['email'] ?? '');
                $sheet = (new TenantSheets($this->store))->provision($uid, $tenant, $boundId);
                if ($boundId === '') {
                    $this->firebase->put('ogipos_server/tenant_sheets/' . $uid, [
                        'spreadsheetId' => $sheet['spreadsheetId'], 'slug' => $slug,
                        'createdAt' => (int) (microtime(true) * 1000),
                    ]);
                }
                $this->firebase->patch('tenants/' . $uid, [
                    'spreadsheetId' => $sheet['spreadsheetId'], 'spreadsheetUrl' => $sheet['spreadsheetUrl'],
                    'provisioningStatus' => 'ready', 'provisioningError' => null, 'updatedAt' => (int) (microtime(true) * 1000),
                ]);
                return $sheet;
            } catch (\Throwable $error) {
                $this->firebase->patch('tenants/' . $uid, [
                    'provisioningStatus' => 'retry', 'provisioningError' => 'Setup spreadsheet perlu diulang.',
                    'updatedAt' => (int) (microtime(true) * 1000),
                ]);
                throw $error;
            }
        });
    }

    public function handle(array $input): array
    {
        $uid = $this->firebase->uid();
        $profile = $this->firebase->get('users/' . $uid);
        $role = (string) ($profile['role'] ?? '');
        $tenantId = (string) ($profile['tenantId'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_-]{6,128}$/', $tenantId)
            || ($profile['active'] ?? false) !== true || !in_array($role, ['owner', 'admin', 'kasir'], true)) {
            throw new ApiError('Akun kasir tidak aktif.', 403);
        }
        $tenant = $this->firebase->get('tenants/' . $tenantId);
        $member = $this->firebase->get('tenantMembers/' . $tenantId . '/' . $uid);
        $slug = Web::slug((string) ($tenant['slug'] ?? ''));
        if (($tenant['ownerUid'] ?? '') !== $tenantId
            || ($member['tenantId'] ?? '') !== $tenantId || ($member['role'] ?? '') !== $role
            || ($member['active'] ?? false) !== true
            || (isset($input['tenantId']) && $input['tenantId'] !== $tenantId)
            || (isset($input['tenantSlug']) && $input['tenantSlug'] !== $slug)) {
            throw new ApiError('Tenant tidak sesuai dengan akun.', 403);
        }
        $status = (string) ($tenant['status'] ?? '');
        $trialValid = $status === 'trial' && (int) ($tenant['trialExpired'] ?? 0) > (int) (microtime(true) * 1000);
        $lifetimeValid = $status === 'active' && ($tenant['lifetime'] ?? false) === true;
        if ((!$trialValid && !$lifetimeValid) || !empty($tenant['maintenance'])) {
            throw new ApiError('Akses tenant tidak aktif. Selesaikan aktivasi atau hubungi admin.', 403);
        }
        $sheetId = (string) ($tenant['spreadsheetId'] ?? '');
        $binding = $this->firebase->get('ogipos_server/tenant_sheets/' . $tenantId);
        // Self-heal a missing/stale binding only as the authenticated tenant Owner.
        // provision() checks the sheet's Meta tenantId and slug before repairing
        // Firebase records. This NEVER creates a replacement for a legacy sheet.
        if (($sheetId === '' || ($binding['spreadsheetId'] ?? '') !== $sheetId
            || ($binding['slug'] ?? '') !== $slug) && $role === 'owner') {
            $this->provision();
            $tenant = $this->firebase->get('tenants/' . $tenantId);
            $sheetId = (string) ($tenant['spreadsheetId'] ?? '');
            $binding = $this->firebase->get('ogipos_server/tenant_sheets/' . $tenantId);
        }
        if ($sheetId === '' || ($binding['spreadsheetId'] ?? '') !== $sheetId
            || ($binding['slug'] ?? '') !== $slug) {
            throw new ApiError('Binding Cloud Database tidak sesuai. Owner harus login untuk memverifikasi Spreadsheet tenant.', 503);
        }
        $action = (string) ($input['action'] ?? '');
        if (!in_array($action, [
            'read', 'syncTenantMeta', 'upsertCustomer', 'addTransaction', 'addService', 'editService',
            'deleteService', 'updateStatus', 'updatePaymentStatus', 'addExpense', 'backupData', 'clearData',
        ], true)) {
            throw new ApiError('Aksi POS tidak dikenal.');
        }
        if (in_array($action, ['syncTenantMeta', 'backupData', 'clearData'], true) && $role !== 'owner'
            || $action === 'deleteService' && !in_array($role, ['owner', 'admin'], true)) {
            throw new ApiError('Peran akun tidak memiliki akses.', 403);
        }
        $sheets = new TenantSheets($this->store);
        if ($action === 'read') {
            return ['ok' => true, 'transactions' => $sheets->rows($sheetId, 'Transactions'),
                'customServices' => $sheets->rows($sheetId, 'Services'),
                'customers' => $sheets->rows($sheetId, 'Customers'),
                'expenses' => $sheets->rows($sheetId, 'Expenses')];
        }
        return $this->store->locked('sheet-' . $tenantId, fn(): array =>
            $this->writeAction($sheets, $sheetId, $tenantId, $slug, $uid, $profile, $tenant, $action, $input));
    }

    private function writeAction(
        TenantSheets $sheets, string $id, string $tenantId, string $slug, string $uid,
        array $profile, array $tenant, string $action, array $p,
    ): array {
        $now = gmdate('c');
        if ($action === 'syncTenantMeta') {
            $sheets->write($id, 'Meta!A2', [
                ['tenantId', $tenantId], ['slug', $slug], ['name', (string) ($tenant['name'] ?? '')],
                ['phone', (string) ($tenant['phone'] ?? '')], ['address', (string) ($tenant['address'] ?? '')],
                ['receiptFooter', (string) ($tenant['receiptFooter'] ?? '')], ['ownerUid', $tenantId],
                ['updatedAt', $now],
            ]);
            return ['ok' => true];
        }
        if ($action === 'upsertCustomer') {
            $customerId = $this->id($p['id'] ?? '', 'customer.id');
            $name = $this->str($p['name'] ?? '', 'Nama pelanggan');
            $rows = $sheets->rows($id, 'Customers');
            foreach ($rows as $row) {
                if (($row['id'] ?? '') === $customerId) {
                    $sheets->updateById($id, 'Customers', 'id', $customerId, [
                        'name' => $name, 'phone' => (string) ($p['phone'] ?? ''),
                        'updatedAt' => $now, 'cashierUid' => $uid,
                    ]);
                    return ['ok' => true];
                }
            }
            $sheets->append($id, 'Customers', [
                'id' => $customerId, 'name' => $name, 'phone' => (string) ($p['phone'] ?? ''),
                'createdAt' => $now, 'updatedAt' => $now, 'cashierUid' => $uid,
            ]);
            return ['ok' => true];
        }
        if ($action === 'addTransaction') {
            $orderId = $this->id($p['id'] ?? '', 'ID nota');
            foreach ($sheets->rows($id, 'Transactions') as $row) {
                if (($row['id'] ?? '') === $orderId) {
                    return ['ok' => true, 'id' => $orderId, 'alreadySaved' => true];
                }
            }
            $serviceRows = $sheets->rows($id, 'Services');
            $serviceById = array_column($serviceRows, null, 'id');
            $requested = $p['items'] ?? [];
            if (!is_array($requested) || !$requested || count($requested) > 100) {
                throw new ApiError('Item transaksi wajib diisi.');
            }
            $items = [];
            $subtotal = 0;
            foreach ($requested as $item) {
                $serviceId = $this->id($item['id'] ?? '', 'Layanan');
                if (!isset($serviceById[$serviceId])) {
                    throw new ApiError('Layanan tidak ditemukan: ' . $serviceId);
                }
                $master = $serviceById[$serviceId];
                $price = (int) ($master['price'] ?? 0);
                $type = ($master['type'] ?? '') === 'Kiloan' ? 'Kiloan' : 'Satuan';
                $qty = (float) ($item['qty'] ?? 0);
                if ($qty <= 0 || $qty > 10000 || $price < 0) {
                    throw new ApiError('Jumlah atau harga layanan tidak valid.');
                }
                $qty = $type === 'Kiloan' ? round($qty, 2) : max(1, round($qty));
                $items[] = ['id' => $serviceId, 'name' => $master['name'], 'price' => $price, 'qty' => $qty, 'type' => $type];
                $subtotal += $this->roundPrice($price * $qty);
            }
            $discount = min($subtotal, max(0, (int) ($p['discount'] ?? 0)));
            $total = max(0, $subtotal - $discount);
            if (isset($p['grandTotal']) && (int) $p['grandTotal'] !== $total) {
                throw new ApiError('Harga layanan berubah. Muat ulang POS sebelum membuat nota.', 409);
            }
            $paid = max(0, (int) ($p['paidAmount'] ?? $p['cashPaid'] ?? 0));
            $paymentStatus = ($p['paymentStatus'] ?? '') === 'Belum Bayar' ? 'Belum Bayar' : 'Lunas';
            if ($paymentStatus === 'Lunas' && $paid < $total) {
                throw new ApiError('Uang diterima kurang dari total pembayaran.');
            }
            $method = (string) ($p['paymentMethod'] ?? $p['method'] ?? 'Tunai / Cash');
            if (!in_array($method, ['Tunai / Cash', 'QRIS', 'Transfer Bank'], true)) {
                throw new ApiError('Metode pembayaran tidak valid.');
            }
            $serviceLabel = implode(', ', array_map(static fn(array $i): string =>
                $i['name'] . ' (' . str_replace('.', ',', (string) $i['qty']) . ($i['type'] === 'Kiloan' ? ' kg' : ' satuan') . ')', $items));
            $sheets->append($id, 'Transactions', [
                'id' => $orderId, 'customer' => $this->str($p['customer'] ?? '', 'Pelanggan'),
                'customerId' => (string) ($p['customerId'] ?? ''), 'phone' => (string) ($p['phone'] ?? ''),
                'service' => $serviceLabel, 'total' => $total, 'cashier' => (string) ($profile['name'] ?? $uid),
                'status' => $this->orderStatus($p['status'] ?? 'pending'), 'method' => $method,
                'paymentStatus' => $paymentStatus, 'cashPaid' => $paid, 'cashChange' => max(0, $paid - $total),
                'itemsDetail' => json_encode($items, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                'date' => (string) ($p['date'] ?? $now), 'estimatedPickup' => (string) ($p['estimatedPickup'] ?? ''),
                'cashierUid' => $uid, 'subtotal' => $subtotal, 'discount' => $discount,
                'grandTotal' => $total, 'tenantId' => $tenantId,
            ]);
            return ['ok' => true, 'id' => $orderId, 'grandTotal' => $total];
        }
        if ($action === 'addService') {
            $serviceId = $this->id($p['id'] ?? '', 'ID layanan');
            foreach ($sheets->rows($id, 'Services') as $row) {
                if (($row['id'] ?? '') === $serviceId) {
                    throw new ApiError('ID layanan sudah ada.', 409);
                }
            }
            $type = $this->serviceType($p['type'] ?? '');
            $price = (int) ($p['price'] ?? 0);
            if ($price <= 0 || $price > 100000000) {
                throw new ApiError('Harga layanan tidak valid.');
            }
            $sheets->append($id, 'Services', ['id' => $serviceId, 'name' => $this->str($p['name'] ?? '', 'Layanan'),
                'price' => $price, 'type' => $type, 'icon' => (string) ($p['icon'] ?? 'fa-box-tissue'), 'createdAt' => $now]);
            return ['ok' => true];
        }
        if ($action === 'editService') {
            $price = (int) ($p['price'] ?? 0);
            if ($price <= 0 || $price > 100000000) {
                throw new ApiError('Harga layanan tidak valid.');
            }
            $sheets->updateById($id, 'Services', 'id', $this->id($p['id'] ?? '', 'ID layanan'), [
                'name' => $this->str($p['name'] ?? '', 'Layanan'), 'price' => $price,
                'type' => $this->serviceType($p['type'] ?? ''),
            ]);
            return ['ok' => true];
        }
        if ($action === 'deleteService') {
            $sheets->deleteById($id, 'Services', $this->id($p['id'] ?? '', 'ID layanan'));
            return ['ok' => true];
        }
        if ($action === 'updateStatus') {
            $sheets->updateById($id, 'Transactions', 'id', $this->id($p['id'] ?? '', 'ID nota'), [
                'status' => $this->orderStatus($p['status'] ?? ''),
            ]);
            return ['ok' => true];
        }
        if ($action === 'updatePaymentStatus') {
            $status = (string) ($p['paymentStatus'] ?? '');
            if (!in_array($status, ['Lunas', 'Belum Bayar'], true)) {
                throw new ApiError('Status pembayaran tidak valid.');
            }
            $sheets->updateById($id, 'Transactions', 'id', $this->id($p['id'] ?? '', 'ID nota'), ['paymentStatus' => $status]);
            return ['ok' => true];
        }
        if ($action === 'addExpense') {
            $expenseId = $this->id($p['id'] ?? '', 'ID pengeluaran');
            foreach ($sheets->rows($id, 'Expenses') as $row) {
                if (($row['id'] ?? '') === $expenseId) {
                    return ['ok' => true, 'alreadySaved' => true];
                }
            }
            $amount = (int) ($p['nominal'] ?? 0);
            if ($amount <= 0) {
                throw new ApiError('Nominal pengeluaran tidak valid.');
            }
            $sheets->append($id, 'Expenses', ['id' => $expenseId, 'tanggal' => (string) ($p['tanggal'] ?? $now),
                'keterangan' => $this->str($p['keterangan'] ?? '', 'Keterangan'), 'nominal' => $amount,
                'sumber_dana' => (string) ($p['sumber_dana'] ?? '')]);
            return ['ok' => true];
        }
        $filter = $this->maintenanceFilter($p);
        $transactions = $sheets->rows($id, 'Transactions');
        $expenses = $sheets->rows($id, 'Expenses');
        $matchedTx = array_values(array_filter($transactions, fn($r) => $this->inPeriod($r['date'] ?? '', $filter)));
        $matchedEx = array_values(array_filter($expenses, fn($r) => $this->inPeriod($r['tanggal'] ?? '', $filter)));
        if ($action === 'backupData') {
            $result = $sheets->backup($id, $tenantId, ['slug' => $slug,
                'ownerEmail' => (string) ($profile['email'] ?? ''), 'Transactions' => $matchedTx,
                'Expenses' => $matchedEx, 'Customers' => $sheets->rows($id, 'Customers'),
                'Services' => $sheets->rows($id, 'Services')]);
            $this->firebase->put('ogipos_server/backups/' . $tenantId, [
                'sheetId' => (string) ($result['spreadsheetId'] ?? ''),
                'createdAt' => (int) (microtime(true) * 1000),
                'mode' => $filter['mode'], 'scope' => $filter['scope'],
                'startDate' => $filter['start'], 'endDate' => $filter['end'],
            ]);
            return $result;
        }
        if ($action === 'clearData') {
            if (($p['backupConfirmed'] ?? false) !== true) {
                throw new ApiError('Backup wajib dikonfirmasi sebelum menghapus data.');
            }
            $backup = $this->firebase->get('ogipos_server/backups/' . $tenantId);
            if (($backup['sheetId'] ?? '') === ''
                || (int) ($backup['createdAt'] ?? 0) < (int) (microtime(true) * 1000) - 86400000
                || ($backup['mode'] ?? '') !== $filter['mode'] || ($backup['scope'] ?? '') !== $filter['scope']
                || ($backup['startDate'] ?? '') !== $filter['start'] || ($backup['endDate'] ?? '') !== $filter['end']) {
                throw new ApiError('Buat backup Spreadsheet dengan filter yang sama sebelum menghapus data.', 409);
            }
            $keepTx = array_values(array_filter($transactions, fn($r) => !$this->inPeriod($r['date'] ?? '', $filter)));
            $keepEx = array_values(array_filter($expenses, fn($r) => !$this->inPeriod($r['tanggal'] ?? '', $filter)));
            $sheets->replaceRows($id, 'Transactions', $keepTx);
            $sheets->replaceRows($id, 'Expenses', $keepEx);
            $deletedCustomers = 0;
            $deletedServices = 0;
            if ($filter['scope'] === 'all-pos-data' && $filter['mode'] === 'all') {
                $deletedCustomers = count($sheets->rows($id, 'Customers'));
                $deletedServices = count($sheets->rows($id, 'Services'));
                $sheets->replaceRows($id, 'Customers', []);
                $sheets->replaceRows($id, 'Services', []);
            }
            $this->firebase->patch('', ['ogipos_server/backups/' . $tenantId => null]);
            return ['ok' => true, 'deletedTransactions' => count($matchedTx),
                'deletedExpenses' => count($matchedEx), 'deletedCustomers' => $deletedCustomers,
                'deletedServices' => $deletedServices];
        }
        throw new ApiError('Aksi belum ditangani.');
    }

    public function track(string $slug, string $orderId): array
    {
        $slug = Web::slug($slug);
        $orderId = $this->id($orderId, 'ID nota');
        $public = $this->firebase->get('publicTenants/' . $slug);
        $tenantId = (string) ($public['tenantId'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_-]{6,128}$/', $tenantId)) {
            return ['ok' => true, 'transactions' => []];
        }
        $private = $this->firebase->get('tenants/' . $tenantId);
        if (($private['slug'] ?? '') !== $slug || !empty($private['maintenance'])) {
            return ['ok' => true, 'transactions' => []];
        }
        $sheetId = (string) ($private['spreadsheetId'] ?? '');
        $binding = $this->firebase->get('ogipos_server/tenant_sheets/' . $tenantId);
        if ($sheetId === '' || ($binding['spreadsheetId'] ?? '') !== $sheetId
            || ($binding['slug'] ?? '') !== $slug) {
            return ['ok' => true, 'transactions' => []];
        }
        foreach ((new TenantSheets($this->store))->rows($sheetId, 'Transactions') as $row) {
            if (($row['id'] ?? '') === $orderId) {
                return ['ok' => true, 'transactions' => [[
                    'id' => $row['id'], 'customer' => $row['customer'], 'service' => $row['service'],
                    'total' => $row['total'], 'status' => $row['status'],
                    'paymentStatus' => $row['paymentStatus'], 'date' => $row['date'],
                    'estimatedPickup' => $row['estimatedPickup'] ?? '',
                ]]];
            }
        }
        return ['ok' => true, 'transactions' => []];
    }

    private function id(mixed $value, string $name): string
    {
        $id = trim((string) $value);
        if (!preg_match('/^[A-Za-z0-9_-]{1,80}$/', $id)) {
            throw new ApiError($name . ' tidak valid.');
        }
        return $id;
    }

    private function str(mixed $value, string $name): string
    {
        $text = trim((string) $value);
        if ($text === '' || (function_exists('mb_strlen') ? mb_strlen($text) : strlen($text)) > 200) {
            throw new ApiError($name . ' tidak valid.');
        }
        return $text;
    }

    private function orderStatus(mixed $status): string
    {
        $map = ['pending'=>'pending','baru'=>'pending','diterima'=>'pending',
            'processing'=>'processing','proses'=>'processing','diproses'=>'processing',
            'completed'=>'completed','selesai'=>'completed','picked_up'=>'picked_up',
            'diambil'=>'picked_up','cancelled'=>'cancelled','batal'=>'cancelled'];
        $value = $map[strtolower(trim((string) $status))] ?? null;
        if (!$value) {
            throw new ApiError('Status transaksi tidak valid.');
        }
        return $value;
    }

    private function serviceType(mixed $type): string
    {
        $value = strtolower(trim((string) $type));
        if (in_array($value, ['kiloan', 'kg'], true)) return 'Kiloan';
        if (in_array($value, ['satuan', 'pcs', 'unit'], true)) return 'Satuan';
        throw new ApiError('Tipe layanan tidak valid.');
    }

    private function roundPrice(float $value): int
    {
        $rounded = (int) round($value);
        $rem = $rounded % 1000;
        return $rounded - $rem + ($rem < 400 ? 0 : ($rem < 800 ? 500 : 1000));
    }

    private function maintenanceFilter(array $p): array
    {
        $mode = (string) ($p['mode'] ?? 'all');
        $scope = (string) ($p['scope'] ?? 'transactions-expenses');
        if (!in_array($mode, ['all', 'week', 'month', 'date', 'range'], true)
            || !in_array($scope, ['transactions-expenses', 'all-pos-data'], true)) {
            throw new ApiError('Filter backup tidak valid.');
        }
        $start = (string) ($p['startDate'] ?? '');
        $end = (string) ($p['endDate'] ?? '');
        if ($mode !== 'all' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)
            || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end) || $start > $end)) {
            throw new ApiError('Rentang tanggal backup tidak valid.');
        }
        return compact('mode', 'scope', 'start', 'end');
    }

    private function inPeriod(mixed $value, array $filter): bool
    {
        if ($filter['mode'] === 'all') return true;
        try {
            $date = (new \DateTimeImmutable((string) $value, new \DateTimeZone('Asia/Jakarta')))->setTimezone(new \DateTimeZone('Asia/Jakarta'))->format('Y-m-d');
        } catch (\Throwable $error) {
            return false;
        }
        return $date >= $filter['start'] && $date <= $filter['end'];
    }
}
