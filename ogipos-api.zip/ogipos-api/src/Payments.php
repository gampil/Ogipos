<?php
declare(strict_types=1);

namespace Ogipos;

final class Cashi
{
    /** Cashi has returned both direct objects and objects nested below data/order/payment. */
    public static function providerData(array $payload): array
    {
        $data = is_array($payload['data'] ?? null) ? array_replace($payload, $payload['data']) : $payload;
        unset($data['data']);
        foreach (['order', 'payment', 'transaction'] as $key) {
            if (is_array($data[$key] ?? null)) $data = array_replace($data, $data[$key]);
        }
        return $data;
    }

    private static function rupiah(mixed $value): ?int
    {
        if (is_int($value)) return $value >= 0 ? $value : null;
        if (is_float($value)) return is_finite($value) && $value >= 0 && floor($value) === $value ? (int) $value : null;
        if (!is_string($value)) return null;
        $value = trim($value);
        if (!preg_match('/^[0-9]{1,12}(?:\.0{1,4})?$/', $value)) return null;
        $number = (float) $value;
        return $number >= 0 && floor($number) === $number ? (int) $number : null;
    }

    /** Prefer the total payable amount; some Cashi responses split base amount and unique code. */
    public static function payableAmount(array $data): ?int
    {
        foreach (['total_amount', 'totalAmount', 'payable_amount', 'payableAmount', 'paid_amount', 'paidAmount'] as $key) {
            $value = self::rupiah($data[$key] ?? null);
            if ($value !== null) return $value;
        }
        $base = self::rupiah($data['amount'] ?? null);
        if ($base === null) return null;
        foreach (['unique_code', 'uniqueCode', 'amount_adjustment', 'amountAdjustment'] as $key) {
            if (!array_key_exists($key, $data)) continue;
            $adjustment = self::rupiah($data[$key]);
            if ($adjustment !== null) return $base + $adjustment;
        }
        return $base;
    }

    public static function status(array $data, array $root = []): string
    {
        foreach (['payment_status', 'paymentStatus', 'transaction_status', 'transactionStatus'] as $key) {
            $value = $data[$key] ?? $root[$key] ?? null;
            if (is_string($value) && trim($value) !== '') return strtoupper(trim($value));
        }
        // With a data envelope, root.status can mean that the API call itself
        // succeeded. Only treat the nested status as the payment state.
        if (is_array($root['data'] ?? null)) {
            $nested = self::providerData($root['data']);
            $value = $nested['status'] ?? null;
            return is_string($value) && trim($value) !== '' ? strtoupper(trim($value)) : '';
        }
        $value = $data['status'] ?? $root['status'] ?? null;
        return is_string($value) && trim($value) !== '' ? strtoupper(trim($value)) : '';
    }

    public static function settled(string $status): bool
    {
        return in_array(strtoupper($status), ['SETTLED', 'PAID', 'SUCCESS', 'COMPLETED'], true);
    }

    public static function expired(string $status): bool
    {
        return in_array(strtoupper($status), ['EXPIRED', 'CANCELLED', 'CANCELED', 'FAILED'], true);
    }

    public static function paymentMethodMatches(mixed $value): bool
    {
        if ($value === null) return true;
        if (!is_string($value) && !is_int($value)) return false;
        if (trim((string) $value) === '') return true;
        return in_array(strtoupper(trim((string) $value)), ['QRIS_CUSTOM', 'QRIS'], true);
    }

    private static function endpoint(string $key): string
    {
        $url = Config::need($key);
        $parts = parse_url($url);
        if (($parts['scheme'] ?? '') !== 'https' || ($parts['host'] ?? '') !== 'cashi.id'
            || !str_starts_with((string) ($parts['path'] ?? ''), '/api/')
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment'])) {
            throw new ApiError('Endpoint Cashi tidak valid.', 503);
        }
        return $url;
    }

    public function create(string $orderId, int $amount): array
    {
        try {
            $result = Web::request('POST', self::endpoint('OGIPOS_CASHI_CREATE_URL'), [
                'amount' => $amount, 'order_id' => $orderId, 'kode_channel' => 'QRIS_CUSTOM',
            ], ['x-api-key: ' . Config::need('OGIPOS_CASHI_API_KEY')]);
        } catch (ApiError $error) {
            if ($error->upstreamStatus === 409) {
                throw new ApiError('Cashi menolak pembuatan QRIS (409). Periksa akses merchant QRIS_CUSTOM, endpoint API, dan log hosting.', 502, $error->upstreamStatus);
            }
            if (in_array($error->upstreamStatus, [401, 403], true)) {
                throw new ApiError('Akses Cashi ditolak. Periksa API key dan izin QRIS_CUSTOM merchant di konfigurasi backend.', 502, $error->upstreamStatus);
            }
            if ($error->upstreamStatus === 404) {
                throw new ApiError('Endpoint pembuatan QRIS Cashi tidak ditemukan. Sesuaikan OGIPOS_CASHI_CREATE_URL dengan dokumentasi merchant.', 502, $error->upstreamStatus);
            }
            throw $error;
        }
        try {
            return self::normalizeOrder($result, $orderId, $amount);
        } catch (ApiError $error) {
            self::logRejectedOrder($result, $orderId, $amount, $error->getMessage());
            throw $error;
        }
    }

    private static function safeProviderText(mixed $value): string
    {
        if (!is_string($value) && !is_int($value) && !is_float($value)) return '';
        $text = (string) $value;
        // Redact configured secrets before truncating; never log the complete response.
        $keys = array_unique(array_merge(array_keys($_ENV), [
            'OGIPOS_CASHI_API_KEY', 'OGIPOS_CASHI_WEBHOOK_SECRET',
            'OGIPOS_GOOGLE_CLIENT_SECRET', 'OGIPOS_ENCRYPTION_KEY',
            'OGIPOS_FIREBASE_API_KEY',
        ]));
        foreach ($keys as $key) {
            if (!preg_match('/KEY|SECRET|TOKEN|PASSWORD/', (string) $key)) continue;
            $secret = Config::get((string) $key);
            if ($secret !== '') $text = str_replace($secret, '[redacted]', $text);
        }
        $text = preg_replace('~https?://[^\s]+|data:image/[^\s]+~i', '[redacted-url]', $text) ?? '';
        $text = preg_replace('/[A-Za-z0-9_+\/-]{24,}={0,2}/', '[redacted-token]', $text) ?? '';
        $text = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $text) ?? '';
        return substr($text, 0, 300);
    }

    private static function logRejectedOrder(array $result, string $orderId, int $amount, string $reason): void
    {
        $data = is_array($result['data'] ?? null) ? $result['data'] : $result;
        $success = $result['success'] ?? $data['success'] ?? null;
        $reported = $data['amount'] ?? null;
        $providerError = $data['message'] ?? $result['message'] ?? $data['error'] ?? $result['error'] ?? '';
        if (is_array($providerError)) $providerError = $providerError['message'] ?? '';
        $summary = [
            'orderId' => $orderId, 'reason' => $reason,
            'successType' => get_debug_type($success),
            'successValue' => is_bool($success) || is_int($success) ? $success
                : (is_string($success) && in_array($success, ['true', 'false', '0', '1'], true) ? $success : null),
            'expectedAmount' => $amount, 'receivedAmountType' => get_debug_type($reported),
            'receivedAmount' => (is_int($reported) || is_float($reported)
                || (is_string($reported) && preg_match('/^[0-9]{1,12}(?:\.[0-9]{1,4})?$/', $reported))) ? $reported : null,
            'wrappedData' => is_array($result['data'] ?? null),
            'hasQr' => !empty($data['qrUrl']) || !empty($data['qr_url']),
            'hasCheckout' => !empty($data['checkout_url']) || !empty($data['checkoutUrl']),
            'providerMessage' => self::safeProviderText($providerError),
        ];
        error_log('OGIPOS Cashi create rejected: ' . json_encode($summary,
            JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR));
    }

    // Accept direct and wrapped Cashi responses while keeping strict order and amount checks.
    public static function normalizeOrder(array $result, string $orderId, int $amount): array
    {
        $data = self::providerData($result);
        $success = $result['success'] ?? $data['success'] ?? false;
        if (!in_array($success, [true, 1, '1', 'true'], true)) {
            throw new ApiError('Cashi tidak mengembalikan success=true. Lihat baris OGIPOS Cashi create rejected pada error_log hosting.', 502);
        }
        // The authenticated create response can include a small amount adjustment.
        // Store the exact QRIS payable amount. Authenticated status responses may
        // later represent it as either this total or the server-owned base amount.
        $payableAmount = self::payableAmount($data);
        if ($payableAmount === null || $payableAmount <= 0) {
            throw new ApiError('Nominal bayar Cashi harus berupa rupiah bulat. Lihat baris OGIPOS Cashi create rejected pada error_log hosting.', 502);
        }
        // Application guard, not a claim about Cashi's maximum unique-code range.
        if ($payableAmount < $amount || $payableAmount > min(10000000, $amount + 999)) {
            throw new ApiError('Nominal bayar Cashi di luar batas penyesuaian invoice (Rp0–Rp999). Lihat baris OGIPOS Cashi create rejected pada error_log hosting.', 502);
        }
        $url = trim((string) ($data['checkout_url'] ?? $data['checkoutUrl'] ?? ''));
        if ($url !== '' && !self::validCashiUrl($url)) {
            throw new ApiError('Tautan checkout Cashi tidak valid.', 502);
        }
        $qr = self::normalizeQr((string) ($data['qrUrl'] ?? $data['qr_url'] ?? ''));
        if ($url === '' && $qr === '') {
            throw new ApiError('Cashi tidak mengirim gambar QRIS maupun tautan checkout. Periksa endpoint dan respons merchant.', 502);
        }
        $gatewayId = (string) ($data['orderId'] ?? $data['order_id'] ?? $data['id'] ?? $orderId);
        if (!preg_match('/^[A-Za-z0-9_-]{1,128}$/', $gatewayId)) {
            throw new ApiError('ID transaksi Cashi tidak valid.', 502);
        }
        return ['checkoutUrl' => $url, 'qrUrl' => $qr, 'gatewayOrderId' => $gatewayId, 'amount' => $payableAmount,
            'expiresAt' => self::expiryMs($data['expires_at'] ?? $data['expiresAt'] ?? $data['expired_at'] ?? null)];
    }

    private static function validCashiUrl(string $url): bool
    {
        $parts = parse_url($url);
        return is_array($parts) && ($parts['scheme'] ?? '') === 'https'
            && strtolower((string) ($parts['host'] ?? '')) === 'cashi.id'
            && !isset($parts['user']) && !isset($parts['pass'])
            && (!isset($parts['port']) || $parts['port'] === 443);
    }

    public static function normalizeQr(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') return '';
        if (strlen($raw) > 800000) throw new ApiError('Gambar QRIS Cashi terlalu besar.', 502);
        if (self::validCashiUrl($raw)) return $raw;
        if (!preg_match('~^data:image/(png|jpe?g|webp);base64,([A-Za-z0-9+/=\s]+)$~i', $raw, $match)) {
            throw new ApiError('Format gambar QRIS Cashi tidak didukung.', 502);
        }
        $base64 = preg_replace('/\s+/', '', $match[2]);
        $bytes = base64_decode($base64, true);
        $mime = strtolower($match[1]);
        if ($mime === 'jpg') $mime = 'jpeg';
        $valid = is_string($bytes) && match ($mime) {
            'png' => str_starts_with($bytes, "\x89PNG\r\n\x1a\n"),
            'jpeg' => str_starts_with($bytes, "\xff\xd8\xff"),
            'webp' => str_starts_with($bytes, 'RIFF') && substr($bytes, 8, 4) === 'WEBP',
            default => false,
        };
        if (!$valid) throw new ApiError('Isi gambar QRIS Cashi tidak valid.', 502);
        return 'data:image/' . $mime . ';base64,' . base64_encode($bytes);
    }

    public static function expiryMs(mixed $value): ?int
    {
        if ($value === null || $value === '' || $value === 0 || $value === '0') return null;
        if (is_int($value) || (is_string($value) && ctype_digit($value))) {
            $number = (int) $value;
            if ($number <= 0) return null;
            return $number < 100000000000 ? $number * 1000 : $number;
        }
        if (!is_string($value) || strlen($value) > 64 || !preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?$/', $value)) return null;
        try { return (new \DateTimeImmutable($value, new \DateTimeZone('Asia/Jakarta')))->getTimestamp() * 1000; }
        catch (\Throwable $error) { return null; }
    }

    public function query(string $orderId): array
    {
        if (!preg_match('/^[A-Za-z0-9_-]{1,128}$/', $orderId)) throw new ApiError('ID Cashi tidak valid.');
        $template = self::endpoint('OGIPOS_CASHI_STATUS_URL_TEMPLATE');
        if (substr_count($template, '{orderId}') !== 1) throw new ApiError('URL status Cashi belum valid.', 503);
        return Web::request('GET', str_replace('{orderId}', rawurlencode($orderId), $template), null,
            ['x-api-key: ' . Config::need('OGIPOS_CASHI_API_KEY')]);
    }

    public static function amountMatches(mixed $reported, int $expected, ?int $packageAmount = null): bool
    {
        $amount = is_array($reported) ? self::payableAmount(self::providerData($reported)) : self::rupiah($reported);
        if ($amount === null) return false;
        if ($amount === $expected) return true;
        // Cashi has returned the base merchant amount on status/webhook responses,
        // while the create response (and QRIS) contains base + unique adjustment.
        // Accept that authenticated representation only when both server-owned
        // values differ by the same tightly bounded adjustment used at creation.
        if ($packageAmount === null || $packageAmount <= 0) return false;
        $adjustment = $expected - $packageAmount;
        return $adjustment >= 0 && $adjustment <= 999 && $amount === $packageAmount;
    }
}

final class Payments
{
    public function __construct(private readonly Store $store, private readonly Firebase $firebase) {}
    private function byOrder(string $id): ?array { return $this->store->invoice($id); }
    private function byGatewayOrder(string $id): ?array { return $this->store->invoiceByGateway($id); }
    private function byToken(string $token): ?array { return $this->store->invoiceByToken($token); }

    private function authorizeOwner(string $slug): string
    {
        [$uid] = $this->firebase->owner();
        $tenant = $this->firebase->get('tenants/' . $uid);
        $public = $this->firebase->get('publicTenants/' . $slug);
        if (($tenant['ownerUid'] ?? '') !== $uid || ($tenant['slug'] ?? '') !== $slug
            || ($public['tenantId'] ?? '') !== $uid) throw new ApiError('Aktivasi hanya tersedia untuk Owner usaha ini.', 403);
        return $uid;
    }

    private function view(array $invoice): array
    {
        // Once paid or inactive, never expose the QR payload / provider checkout URL again.
        // This prevents repeat-pay links inside OGIPOS; only Cashi can revoke an already-issued QR externally.
        $payable = in_array((string) ($invoice['status'] ?? ''), ['pending', 'creating'], true);
        // Email delivery is independent from settlement. Never claim it was sent until SMTP confirmed.
        $mail = $invoice['status'] === 'success'
            ? $this->firebase->get('ogipos_server/mail_queue/lifetime-' . $invoice['order_id']) : [];
        $mailStatus = $invoice['status'] === 'success' ? (string) ($mail['status'] ?? 'not_queued') : 'not_due';
        return ['ok' => true, 'paymentId' => $invoice['order_id'], 'tenantSlug' => $invoice['slug'],
            'invoiceEmailStatus' => $mailStatus,
            'tenantName' => (string) ($invoice['tenant_name'] ?? $invoice['slug']),
            'amount' => (int) $invoice['amount'], 'packageAmount' => (int) ($invoice['package_amount'] ?? $invoice['amount']),
            'amountAdjustment' => (int) $invoice['amount'] - (int) ($invoice['package_amount'] ?? $invoice['amount']),
            'package' => 'lifetime', 'status' => $invoice['status'],
            'paymentUrl' => $payable ? ($invoice['checkout_url'] ?? '') : '', 'qrUrl' => $payable ? ($invoice['qr_url'] ?? '') : '',
            'expiresAt' => isset($invoice['expires_at']) ? (int) $invoice['expires_at'] : null,
            'createdAt' => (int) $invoice['created_at'], 'paidAt' => isset($invoice['paid_at']) ? (int) $invoice['paid_at'] : null,
            'publicToken' => $invoice['public_token'],
            'creationState' => (string) ($invoice['creation_state'] ?? 'ready')];
    }

    private function realtime(array $invoice, array $fields = []): array
    {
        $record = array_replace($invoice, $fields);
        return ['orderId' => $record['order_id'], 'status' => $record['status'], 'amount' => (int) $record['amount'],
            'packageAmount' => (int) ($record['package_amount'] ?? $record['amount']),
            'expiresAt' => $record['expires_at'] ?? null, 'updatedAt' => (int) $record['updated_at']];
    }

    private function tenant(string $slug): array
    {
        $tenantId = $this->authorizeOwner($slug);
        $tenant = $this->firebase->get('tenants/' . $tenantId);
        if (($tenant['lifetime'] ?? false) === true && ($tenant['package'] ?? '') === 'lifetime')
            throw new ApiError('Lifetime usaha ini sudah aktif.', 409);
        if (!in_array(($tenant['status'] ?? ''), ['trial', 'expired', 'active'], true) || !empty($tenant['maintenance']))
            throw new ApiError('Pembayaran usaha ini belum tersedia.', 403);
        return [$tenantId, $tenant];
    }

    public function checkout(string $slug): array
    {
        $slug = Web::slug($slug); $tenantId = $this->authorizeOwner($slug);
        $tenant = $this->firebase->get('tenants/' . $tenantId);
        $package = $this->firebase->get('ogipos_master/packages/lifetime');
        $amount = $package ? (int) ($package['price'] ?? 0) : 99000;
        if (($package && ($package['type'] ?? '') !== 'lifetime') || $amount < 2000 || $amount > 10000000)
            throw new ApiError('Harga Lifetime belum tersedia.', 503);
        $active = ($tenant['lifetime'] ?? false) === true && ($tenant['package'] ?? '') === 'lifetime';
        $allowed = !$active && in_array(($tenant['status'] ?? ''), ['trial', 'expired', 'active'], true) && empty($tenant['maintenance']);
        return ['ok' => true, 'tenantSlug' => $slug, 'tenantName' => (string) ($tenant['name'] ?? $slug),
            'packageName' => (string) ($package['name'] ?? 'Lifetime'), 'amount' => $amount,
            'status' => (string) ($tenant['status'] ?? ''), 'lifetimeActive' => $active, 'canPay' => $allowed];
    }

    public function create(string $slug): array
    {
        $slug = Web::slug($slug); $this->authorizeOwner($slug);
        $this->store->guardRate('pay-owner-' . $slug, 60, 3600);
        return $this->store->locked('payment-' . $slug, function () use ($slug): array {
            [$tenantId, $tenant] = $this->tenant($slug);
            $existing = $this->store->activeInvoice($slug);
            if ($existing && ($existing['tenant_id'] ?? '') !== $tenantId)
                throw new ApiError('Identitas invoice tidak sesuai.', 409);
            if ($existing && $existing['status'] === 'success') {
                // A previously paid tenant must never be offered another QRIS.
                $this->settle($existing, true); // idempotent repair when tenant flags were not updated.
                return $this->view($this->byOrder($existing['order_id']) ?? $existing);
            }
            if ($existing && in_array($existing['status'], ['pending', 'creating', 'expired'], true)) {
                // Before allowing a new invoice, verify provider status of the old one.
                // If status cannot be checked, keep or block the old invoice to prevent double charge.
                $due = !empty($existing['expires_at']) && (int) $existing['expires_at'] <= (int) (microtime(true) * 1000);
                $noQr = empty($existing['checkout_url']) && empty($existing['qr_url']);
                $oldPending = $existing['status'] === 'pending' &&
                    (int) ($existing['updated_at'] ?? 0) < (int) (microtime(true) * 1000) - 30000;
                if ($due || $noQr || $existing['status'] === 'expired' || $oldPending) {
                    try { $this->syncProvider($existing, true); }
                    catch (\Throwable $error) {
                        error_log('OGIPOS create invoice reconciliation: ' . $existing['order_id'] . ': ' . $error->getMessage());
                        if ($due || $existing['status'] === 'expired') {
                            throw new ApiError('Status invoice sebelumnya belum bisa dipastikan. Jangan membayar ulang; periksa status Cashi dahulu.', 409);
                        }
                    }
                    $existing = $this->byOrder($existing['order_id']) ?? $existing;
                }
                if ($existing['status'] === 'success') {
                    $this->settle($existing, true);
                    return $this->view($this->byOrder($existing['order_id']) ?? $existing);
                }
                if (!in_array($existing['status'], ['expired', 'failed'], true)) return $this->view($existing);
            }
            $package = $this->firebase->get('ogipos_master/packages/lifetime');
            $amount = $package ? (int) ($package['price'] ?? 0) : 99000;
            if (($package && ($package['type'] ?? '') !== 'lifetime') || $amount < 2000 || $amount > 10000000)
                throw new ApiError('Harga Lifetime belum valid.', 503);
            $now = (int) (microtime(true) * 1000); $orderId = 'OGI' . strtoupper(bin2hex(random_bytes(10)));
            $invoice = ['order_id' => $orderId, 'tenant_id' => $tenantId, 'slug' => $slug,
                'tenant_name' => (string) ($tenant['name'] ?? $slug), 'public_token' => bin2hex(random_bytes(32)),
                'amount' => $amount, 'package_amount' => $amount, 'status' => 'creating', 'creation_state' => 'requesting',
                'created_at' => $now, 'updated_at' => $now, 'paid_at' => null, 'expires_at' => null,
                'checkout_url' => '', 'qr_url' => '', 'gateway_order_id' => $orderId];
            $record = ['id' => $orderId, 'invoiceId' => $orderId, 'gatewayOrderId' => $orderId,
                'tenantId' => $tenantId, 'tenantName' => $invoice['tenant_name'], 'package' => 'lifetime',
                'amount' => $amount, 'packageAmount' => $amount, 'amountAdjustment' => 0, 'status' => 'creating',
                'gateway' => 'cashi', 'paymentUrl' => '', 'createdAt' => $now, 'updatedAt' => $now];
            $this->store->createInvoice($invoice, ['ogipos_master/payments/' . $orderId => $record,
                'tenantPaymentStatus/' . $tenantId => $this->realtime($invoice),
                'ogipos_server/pending_payments/' . $orderId => ['slug' => $slug]]);
            try { $qr = (new Cashi())->create($orderId, $amount); }
            catch (ApiError $error) {
                $definitive = in_array($error->upstreamStatus, [400, 401, 403, 404, 422], true);
                $status = $definitive ? 'failed' : 'pending';
                $fields = ['status' => $status, 'creation_state' => $definitive ? 'rejected' : 'uncertain',
                    'updated_at' => (int) (microtime(true) * 1000)];
                $updates = ['ogipos_master/payments/' . $orderId . '/status' => $status,
                    'tenantPaymentStatus/' . $tenantId => $this->realtime($invoice, $fields)];
                if ($definitive) $updates['ogipos_server/pending_payments/' . $orderId] = null;
                $this->store->updateInvoice($orderId, $fields, $updates);
                throw $error;
            }
            // Webhook can settle while the Cashi create() HTTP call is still in flight.
            // Never downgrade that successful payment back to pending.
            $afterGateway = $this->byOrder($orderId);
            if ($afterGateway && $afterGateway['status'] === 'success') return $this->view($afterGateway);
            $fields = ['checkout_url' => $qr['checkoutUrl'], 'qr_url' => $qr['qrUrl'], 'gateway_order_id' => $qr['gatewayOrderId'],
                'amount' => $qr['amount'], 'package_amount' => $amount, 'expires_at' => $qr['expiresAt'],
                'status' => 'pending', 'creation_state' => 'ready', 'updated_at' => (int) (microtime(true) * 1000)];
            $this->store->updateInvoice($orderId, $fields, [
                'ogipos_master/payments/' . $orderId . '/amount' => $qr['amount'],
                'ogipos_master/payments/' . $orderId . '/amountAdjustment' => $qr['amount'] - $amount,
                'ogipos_master/payments/' . $orderId . '/gatewayOrderId' => $qr['gatewayOrderId'],
                'ogipos_master/payments/' . $orderId . '/paymentUrl' => $qr['checkoutUrl'],
                'ogipos_master/payments/' . $orderId . '/expiresAt' => $qr['expiresAt'],
                'ogipos_master/payments/' . $orderId . '/status' => 'pending',
                'ogipos_master/payments/' . $orderId . '/updatedAt' => $fields['updated_at'],
                'tenantPaymentStatus/' . $tenantId => $this->realtime($invoice, $fields)]);
            return $this->view($this->byOrder($orderId) ?? array_replace($invoice, $fields));
        });
    }

    public function detail(string $token): array
    {
        $invoice = $this->ownedInvoice($token);
        $providerChecked = false;
        if (in_array($invoice['status'], ['pending', 'creating'], true)) {
            try {
                $this->store->guardRate('payment-refresh-' . $invoice['order_id'], 1, 10);
                $this->syncProvider($invoice);
                $providerChecked = true;
            } catch (\Throwable $error) {
                // A failed provider query is not proof the invoice is still unpaid.
                // Tell the UI to HIDE the old QR until provider status is known.
                error_log('OGIPOS payment refresh ' . $invoice['order_id'] . ': ' . $error->getMessage());
            }
        } elseif ($invoice['status'] === 'success') {
            $this->settle($invoice);
        }
        $fresh = $this->byOrder($invoice['order_id']) ?? $invoice;
        $result = $this->view($fresh);
        $result['paymentStatusVerified'] = $fresh['status'] === 'success' || $providerChecked;
        return $result;
    }

    /** Owner-initiated provider reconciliation; surface provider configuration errors explicitly. */
    public function reconcile(string $token): array
    {
        $invoice = $this->ownedInvoice($token);
        $this->store->guardRate('owner-reconcile-' . $invoice['order_id'], 10, 600);
        if ($invoice['status'] !== 'success') $this->syncProvider($invoice);
        else $this->settle($invoice);
        $result = $this->view($this->byOrder($invoice['order_id']) ?? $invoice);
        $result['paymentStatusVerified'] = true;
        return $result;
    }

    private function ownedInvoice(string $token): array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) throw new ApiError('Tautan invoice tidak valid.', 404);
        [$uid] = $this->firebase->owner();
        $invoice = $this->byToken($token);
        if (!$invoice || ($invoice['tenant_id'] ?? '') !== $uid) throw new ApiError('Invoice bukan milik Owner ini.', 403);
        $this->authorizeOwner($invoice['slug']); return $invoice;
    }

    public function pdf(string $token): string
    {
        $invoice = $this->ownedInvoice($token);
        if ($invoice['status'] !== 'success') throw new ApiError('PDF invoice tersedia setelah pembayaran terverifikasi.', 409);
        return InvoicePdf::render($invoice, $this->firebase->get('users/' . $invoice['tenant_id']));
    }

    /** Authenticated, idempotent fallback for hosts where cron or FastCGI is delayed. */
    public function sendInvoiceEmail(string $token): array
    {
        $invoice = $this->ownedInvoice($token);
        if ($invoice['status'] !== 'success') throw new ApiError('Email invoice tersedia setelah pembayaran terverifikasi.', 409);
        $this->settle($invoice);
        $id = 'lifetime-' . $invoice['order_id'];
        (new Notifications($this->firebase, $this->store))->processJob($id);
        $job = $this->firebase->get('ogipos_server/mail_queue/' . $id);
        return ['ok' => true, 'invoiceEmailStatus' => (string) ($job['status'] ?? 'not_queued')];
    }

    public function webhook(string $raw): array
    {
        $signature = strtolower(trim($_SERVER['HTTP_X_GATEWAY_SIGNATURE'] ?? ''));
        if (!preg_match('/^[a-f0-9]{64}$/', $signature)
            || !hash_equals(hash_hmac('sha256', $raw, Config::need('OGIPOS_CASHI_WEBHOOK_SECRET')), $signature))
            throw new ApiError('Signature callback Cashi tidak valid.', 401);
        $payload = json_decode($raw, true);
        if (!is_array($payload)) throw new ApiError('Payload callback tidak valid.');
        $event = strtoupper(str_replace(['.', '-'], '_', trim((string) ($payload['event'] ?? $payload['type'] ?? ''))));
        if (!in_array($event, ['PAYMENT_SETTLED', 'PAYMENT_EXPIRED'], true)) return ['ok' => true, 'ignored' => true];
        $data = Cashi::providerData($payload);
        $orderId = (string) ($data['order_id'] ?? $data['orderId'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_-]{1,128}$/', $orderId)) throw new ApiError('ID pembayaran tidak valid.');
        $invoice = $this->byGatewayOrder($orderId);
        if (!$invoice) {
            error_log('OGIPOS Cashi webhook: valid signature but unknown provider order ' . substr($orderId, 0, 48));
            throw new ApiError('Invoice callback tidak dikenal; periksa order_id provider versus invoice OGIPOS.', 404);
        }
        // The HMAC was verified against the exact raw request body above. For a
        // signed PAYMENT_SETTLED event, this message is itself Cashi's trusted
        // settlement notification: do not block activation on an additional
        // status API request that may be unavailable or return different fields.
        // Enforce the server-owned total/base amount, order and payment method.
        if ($event === 'PAYMENT_SETTLED') {
            $reportedStatus = Cashi::status($data, $payload);
            $method = $data['payment_method'] ?? $data['paymentMethod'] ?? $data['method'] ?? null;
            if (($reportedStatus !== '' && !Cashi::settled($reportedStatus))
                || !Cashi::paymentMethodMatches($method)
                || !Cashi::amountMatches($data, (int) $invoice['amount'], (int) ($invoice['package_amount'] ?? $invoice['amount']))) {
                error_log('OGIPOS webhook rejected: mismatch for invoice ' . $invoice['order_id']);
                throw new ApiError('Nominal, metode, atau status callback tidak sesuai.', 409);
            }
            $this->settle($invoice);
            error_log('OGIPOS webhook settled: ' . $invoice['order_id']);
        } else {
            $reportedStatus = Cashi::status($data, $payload);
            if ($reportedStatus !== '' && !Cashi::expired($reportedStatus))
                throw new ApiError('Status callback kedaluwarsa tidak sesuai.', 409);
            // An expired event must never override an already-settled invoice.
            $this->expire($invoice);
            error_log('OGIPOS webhook expired: ' . $invoice['order_id']);
        }
        return ['ok' => true, 'paymentId' => $invoice['order_id']];
    }

    private function expire(array $invoice, bool $lockHeld = false): void
    {
        $run = function () use ($invoice): void {
            $fresh = $this->byOrder($invoice['order_id']);
            if (!$fresh || !in_array($fresh['status'], ['pending', 'creating'], true)) return;
            $fields = ['status' => 'expired', 'updated_at' => (int) (microtime(true) * 1000)];
            $updates = ['ogipos_master/payments/' . $invoice['order_id'] . '/status' => 'expired',
                'ogipos_master/payments/' . $invoice['order_id'] . '/updatedAt' => $fields['updated_at'],
                'ogipos_server/pending_payments/' . $invoice['order_id'] => null];
            if (($this->store->activeInvoice($fresh['slug'])['order_id'] ?? '') === $fresh['order_id'])
                $updates['tenantPaymentStatus/' . $fresh['tenant_id']] = $this->realtime($fresh, $fields);
            $this->store->updateInvoice($fresh['order_id'], $fields, $updates);
        };
        if ($lockHeld) $run(); else $this->store->locked('payment-' . $invoice['slug'], $run);
    }

    private function settle(array $invoice, bool $lockHeld = false): void
    {
        $run = function () use ($invoice): void {
            $fresh = $this->byOrder($invoice['order_id']);
            if (!$fresh) return;
            $tenantId = $fresh['tenant_id']; $slug = $fresh['slug'];
            $tenant = $this->firebase->get('tenants/' . $tenantId);
            $public = $this->firebase->get('publicTenants/' . $slug);
            $master = $this->firebase->get('ogipos_master/tenants/' . $tenantId);
            if (($tenant['ownerUid'] ?? '') !== $tenantId || ($tenant['slug'] ?? '') !== $slug
                || ($public['tenantId'] ?? '') !== $tenantId || ($master['tenantId'] ?? '') !== $tenantId)
                throw new ApiError('Identitas tenant pembayaran berubah.', 409);
            // Idempotent delivery: never enqueue the Lifetime email a second time.
            // If a prior migration left the tenant trial while invoice is success, repair flags.
            $mailPath = 'ogipos_server/mail_queue/lifetime-' . $fresh['order_id'];
            $mailExisting = $this->firebase->get($mailPath);
            if ($fresh['status'] === 'success'
                && ($tenant['lifetime'] ?? false) === true && ($tenant['package'] ?? '') === 'lifetime'
                && ($public['lifetime'] ?? false) === true && ($master['lifetime'] ?? false) === true) {
                // Repair old settled payments that never queued their PDF invoice.
                if (!$mailExisting) $this->firebase->patch('', Notifications::jobPatch(
                    'lifetime-' . $fresh['order_id'], 'lifetime', $tenantId, ['orderId' => $fresh['order_id']]));
                Notifications::afterResponse($this->firebase, $this->store, 'lifetime-' . $fresh['order_id']);
                return;
            }
            $now = (int) (microtime(true) * 1000);
            $paidAt = ($fresh['status'] === 'success' && !empty($fresh['paid_at'])) ? (int) $fresh['paid_at'] : $now;
            $status = in_array(($tenant['status'] ?? ''), ['suspended', 'maintenance'], true) ? $tenant['status'] : 'active';
            $updates = [];
            foreach (['tenants/' . $tenantId, 'ogipos_master/tenants/' . $tenantId, 'publicTenants/' . $slug] as $base) {
                foreach (['status' => $status, 'package' => 'lifetime', 'lifetime' => true, 'paymentRequired' => false, 'updatedAt' => $now] as $key => $value)
                    $updates[$base . '/' . $key] = $value;
            }
            foreach (['status' => 'success', 'paidAt' => $paidAt, 'updatedAt' => $now] as $key => $value)
                $updates['ogipos_master/payments/' . $fresh['order_id'] . '/' . $key] = $value;
            foreach (['status' => 'success', 'paid_at' => $paidAt, 'updated_at' => $now] as $key => $value)
                $updates['ogipos_server/invoices/' . $fresh['order_id'] . '/' . $key] = $value;
            $updates['ogipos_server/pending_payments/' . $fresh['order_id']] = null;
            $updates['tenantPaymentStatus/' . $tenantId] = $this->realtime($fresh, ['status' => 'success', 'updated_at' => $now]);
            // Existing status=sent must never be reset to pending by a webhook replay.
            if (!$mailExisting) $updates += Notifications::jobPatch(
                'lifetime-' . $fresh['order_id'], 'lifetime', $tenantId, ['orderId' => $fresh['order_id']]);
            $this->firebase->patch('', $updates);
            Notifications::afterResponse($this->firebase, $this->store, 'lifetime-' . $fresh['order_id']);
        };
        if ($lockHeld) $run(); else $this->store->locked('payment-' . $invoice['slug'], $run);
    }

    private function syncProvider(array $invoice, bool $lockHeld = false): void
    {
        if (!$lockHeld) {
            $this->store->locked('payment-' . $invoice['slug'], function () use ($invoice): void {
                $fresh = $this->byOrder($invoice['order_id']);
                if ($fresh && $fresh['status'] !== 'success') $this->syncProvider($fresh, true);
            });
            return;
        }
        $gatewayId = (string) ($invoice['gateway_order_id'] ?: $invoice['order_id']);
        $result = (new Cashi())->query($gatewayId);
        $data = Cashi::providerData($result);
        $status = Cashi::status($data, $result);
        $providerId = (string) ($data['order_id'] ?? $data['orderId'] ?? $data['id'] ?? '');
        $method = $data['payment_method'] ?? $data['paymentMethod'] ?? $data['method'] ?? null;
        $uncertain = in_array(($invoice['creation_state'] ?? ''), ['uncertain', 'requesting'], true);
        if (!in_array($providerId, [$invoice['order_id'], $gatewayId], true)
            || !Cashi::paymentMethodMatches($method))
            throw new ApiError('Identitas atau metode status Cashi tidak sesuai.', 409);
        if ($uncertain && ($data['checkout_url'] ?? $data['checkoutUrl'] ?? $data['qrUrl'] ?? $data['qr_url'] ?? '') !== '') {
            $recovered = Cashi::normalizeOrder(['success' => true, 'data' => $data], $invoice['order_id'], (int) ($invoice['package_amount'] ?? $invoice['amount']));
            $fields = ['amount' => $recovered['amount'], 'qr_url' => $recovered['qrUrl'], 'checkout_url' => $recovered['checkoutUrl'],
                'gateway_order_id' => $recovered['gatewayOrderId'], 'expires_at' => $recovered['expiresAt'], 'creation_state' => 'ready', 'status' => 'pending', 'updated_at' => (int) (microtime(true) * 1000)];
            $this->store->updateInvoice($invoice['order_id'], $fields, [
                'ogipos_master/payments/' . $invoice['order_id'] . '/amount' => $recovered['amount'],
                'ogipos_master/payments/' . $invoice['order_id'] . '/gatewayOrderId' => $recovered['gatewayOrderId'],
                'ogipos_master/payments/' . $invoice['order_id'] . '/paymentUrl' => $recovered['checkoutUrl'],
                'ogipos_master/payments/' . $invoice['order_id'] . '/status' => 'pending',
                'ogipos_master/payments/' . $invoice['order_id'] . '/amountAdjustment' => $recovered['amount'] - (int) ($invoice['package_amount'] ?? $invoice['amount']),
                'ogipos_master/payments/' . $invoice['order_id'] . '/expiresAt' => $recovered['expiresAt'],
                'tenantPaymentStatus/' . $invoice['tenant_id'] => $this->realtime($invoice, $fields)]);
            $invoice = array_replace($invoice, $fields);
        }
        if (!Cashi::amountMatches($data, (int) $invoice['amount'], (int) ($invoice['package_amount'] ?? $invoice['amount'])))
            throw new ApiError('Nominal status Cashi tidak sesuai dengan total invoice.', 409);
        $expiry = Cashi::expiryMs($data['expires_at'] ?? $data['expiresAt'] ?? null);
        if ($expiry !== null && $expiry !== ($invoice['expires_at'] ?? null)) {
            $this->store->updateInvoice($invoice['order_id'], ['expires_at' => $expiry],
                ['ogipos_master/payments/' . $invoice['order_id'] . '/expiresAt' => $expiry,
                 'tenantPaymentStatus/' . $invoice['tenant_id'] => $this->realtime($invoice, ['expires_at' => $expiry])]);
        }
        if (Cashi::settled($status)) $this->settle($invoice, $lockHeld);
        elseif (Cashi::expired($status)) $this->expire($invoice, $lockHeld);
        elseif (!in_array($status, ['PENDING', 'PROCESSING', 'UNPAID', 'WAITING'], true))
            throw new ApiError('Status Cashi tidak dikenali.', 409);
    }

    public function queryAdmin(string $orderId): array
    {
        $this->firebase->admin(); return $this->queryStored($orderId);
    }
    public function queryStored(string $orderId): array
    {
        if (!preg_match('/^OGI[A-F0-9]{20}$/', $orderId)) throw new ApiError('ID invoice tidak valid.');
        $invoice = $this->byOrder($orderId); if (!$invoice) throw new ApiError('Invoice tidak ditemukan.', 404);
        $this->syncProvider($invoice); return $this->view($this->byOrder($orderId) ?? $invoice);
    }
    public function detailAdmin(string $orderId): array
    {
        $this->firebase->admin(); $invoice = $this->byOrder($orderId);
        if (!$invoice) throw new ApiError('Invoice tidak ditemukan.', 404);
        return $this->view($invoice);
    }
}
