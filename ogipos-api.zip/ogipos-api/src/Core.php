<?php
declare(strict_types=1);

namespace Ogipos;

use RuntimeException;

final class ApiError extends RuntimeException
{
    public function __construct(string $message, public readonly int $status = 400, public readonly ?int $upstreamStatus = null)
    {
        parent::__construct($message);
    }
}

final class Config
{
    public static function load(string $path): void
    {
        if (!is_file($path) || !is_readable($path)) return;
        foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') continue;
            if (!preg_match('/^([A-Z][A-Z0-9_]*)\s*=\s*(.*)$/', $line, $match)) continue;
            $key = $match[1];
            if (getenv($key) !== false || isset($_ENV[$key]) || isset($_SERVER[$key])) continue;
            $value = trim($match[2]);
            if (strlen($value) >= 2 && (($value[0] === '"' && substr($value, -1) === '"')
                || ($value[0] === "'" && substr($value, -1) === "'"))) {
                $quote = $value[0];
                $value = substr($value, 1, -1);
                if ($quote === '"') $value = stripcslashes($value);
            } else {
                $value = preg_replace('/\s+#.*$/', '', $value) ?? $value;
            }
            $_ENV[$key] = $value;
        }
    }

    public static function get(string $key, string $fallback = ''): string
    {
        $value = getenv($key);
        if ($value !== false) return trim($value);
        if (isset($_ENV[$key])) return trim((string) $_ENV[$key]);
        if (isset($_SERVER[$key])) return trim((string) $_SERVER[$key]);
        return $fallback;
    }

    public static function need(string $key): string
    {
        $value = self::get($key);
        if ($value === '') {
            throw new ApiError('Konfigurasi server belum lengkap: ' . $key, 503);
        }
        return $value;
    }

}

final class Web
{
    public static function cors(): void
    {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === '') {
            return;
        }
        $parts = parse_url($origin);
        $base = strtolower(Config::get('OGIPOS_BASE_DOMAIN', 'ogipos.com'));
        $host = strtolower($parts['host'] ?? '');
        $local = Config::get('OGIPOS_LOCAL_ORIGIN');
        $allowed = ($parts['scheme'] ?? '') === 'https'
            && ($host === $base || str_ends_with($host, '.' . $base))
            || ($local !== '' && hash_equals($local, $origin));
        if (!$allowed) {
            throw new ApiError('Origin tidak diizinkan.', 403);
        }
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type');
        header('Access-Control-Max-Age: 600');
    }

    public static function input(): array
    {
        if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 1024 * 1024) {
            throw new ApiError('Payload terlalu besar.', 413);
        }
        $raw = file_get_contents('php://input') ?: '{}';
        $data = json_decode($raw, true);
        if (!str_starts_with(ltrim($raw), '{') || !is_array($data)) {
            throw new ApiError('JSON object wajib dikirim.');
        }
        return $data;
    }

    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
        exit;
    }

    public static function bearer(): string
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (!preg_match('/^Bearer\s+(\S+)$/i', $header, $match)) {
            throw new ApiError('Sesi login diperlukan.', 401);
        }
        return $match[1];
    }

    public static function remoteIp(): string
    {
        return substr($_SERVER['REMOTE_ADDR'] ?? 'unknown', 0, 64);
    }

    public static function request(string $method, string $url, ?array $data = null, array $headers = []): array
    {
        $curl = curl_init($url);
        if ($curl === false) {
            throw new ApiError('Layanan eksternal tidak tersedia.', 502);
        }
        $headers[] = 'Accept: application/json';
        if ($data !== null) {
            $headers[] = 'Content-Type: application/json';
        }
        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 18,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_FOLLOWLOCATION => false,
        ];
        if ($data !== null) {
            $options[CURLOPT_POSTFIELDS] = json_encode($data, JSON_THROW_ON_ERROR);
        }
        curl_setopt_array($curl, $options);
        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $error = curl_error($curl);
        curl_close($curl);
        if ($body === false || $status < 200 || $status >= 300) {
            $upstream = is_string($body) ? json_decode($body, true) : null;
            $note = is_array($upstream) ? (string) ($upstream['message'] ?? $upstream['error'] ?? '') : '';
            foreach (['OGIPOS_CASHI_API_KEY','OGIPOS_CASHI_WEBHOOK_SECRET','OGIPOS_GOOGLE_CLIENT_SECRET','OGIPOS_FIREBASE_API_KEY','OGIPOS_ENCRYPTION_KEY'] as $secretKey) {
                $secret = Config::get($secretKey);
                if ($secret !== '') $note = str_replace($secret, '[redacted]', $note);
            }
            $note = preg_replace('/[A-Za-z0-9_+\/-]{24,}={0,2}/', '[redacted-token]', $note) ?? '';
            $note = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $note) ?? '';
            // Provider diagnostics stay server-side; never log a key or complete body.
            error_log('OGIPOS upstream ' . $method . ' ' . parse_url($url, PHP_URL_HOST) .
                ' status=' . $status . ' network=' . $error . ' message=' . substr($note, 0, 160));
            throw new ApiError('Layanan eksternal gagal merespons (' . $status . ').', 502, $status);
        }
        $result = json_decode($body, true);
        if ($body === 'null') {
            return [];
        }
        if (!is_array($result)) {
            throw new ApiError('Respons layanan eksternal bukan JSON object.', 502);
        }
        return $result;
    }

    public static function slug(string $raw): string
    {
        $slug = strtolower(trim($raw));
        if (!preg_match('/^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/', $slug)) {
            throw new ApiError('Slug laundry tidak valid.');
        }
        return $slug;
    }
}

final class Store
{
    private readonly Firebase $firebase;
    private const ROOT = 'ogipos_server';

    public function __construct(?Firebase $firebase = null)
    {
        $this->firebase = $firebase ?? new Firebase();
    }

    public function legacyCutoffMs(): int
    {
        $result = $this->firebase->cas(self::ROOT . '/settings/legacy_cutoff',
            static function (?array $record): array|false {
                if ((int) ($record['value'] ?? 0) > 0) return false;
                return ['value' => (int) (microtime(true) * 1000)];
            });
        return (int) ($result['value']['value'] ?? 0);
    }

    public function guardRate(string $bucket, int $max, int $seconds): void
    {
        $path = self::ROOT . '/limits/' . hash('sha256', $bucket);
        $this->firebase->cas($path, static function (?array $record) use ($max, $seconds): array {
            $now = time();
            $expires = (int) ($record['expires_at'] ?? 0);
            $count = $expires > $now ? (int) ($record['count'] ?? 0) : 0;
            if ($count >= $max) throw new ApiError('Terlalu banyak permintaan. Coba lagi nanti.', 429);
            return ['count' => $count + 1, 'expires_at' => $expires > $now ? $expires : $now + $seconds];
        });
    }

    public function locked(string $key, callable $run): mixed
    {
        $path = self::ROOT . '/locks/' . hash('sha256', $key);
        $owner = bin2hex(random_bytes(16));
        $lease = $this->firebase->cas($path, static function (?array $record) use ($owner): array|false {
            if ((int) ($record['expires_at'] ?? 0) > time()) return false;
            return ['owner' => $owner, 'expires_at' => time() + 300];
        });
        if (!$lease['written']) throw new ApiError('Sedang diproses. Coba beberapa saat lagi.', 409);
        try {
            return $run();
        } finally {
            try {
                $this->firebase->cas($path, static fn(?array $record): array|false|null =>
                    ($record['owner'] ?? '') === $owner ? null : false);
            } catch (\Throwable $error) {
                error_log('OGIPOS lease release failed: ' . $error->getMessage());
            }
        }
    }

    public function invoice(string $orderId): ?array
    {
        if (!preg_match('/^OGI[A-F0-9]{20}$/', $orderId)) return null;
        $record = $this->firebase->get(self::ROOT . '/invoices/' . $orderId);
        return $record ?: null;
    }

    public function invoiceByToken(string $token): ?array
    {
        $index = $this->firebase->get(self::ROOT . '/token_index/' . hash('sha256', $token));
        $invoice = $this->invoice((string) ($index['order_id'] ?? ''));
        return $invoice && hash_equals((string) ($invoice['public_token'] ?? ''), $token) ? $invoice : null;
    }

    public function invoiceByGateway(string $gatewayId): ?array
    {
        $invoice = $this->invoice($gatewayId);
        if ($invoice) return $invoice;
        $index = $this->firebase->get(self::ROOT . '/gateway_index/' . hash('sha256', $gatewayId));
        $invoice = $this->invoice((string) ($index['order_id'] ?? ''));
        return $invoice && ($invoice['gateway_order_id'] ?? '') === $gatewayId ? $invoice : null;
    }

    public function activeInvoice(string $slug): ?array
    {
        $index = $this->firebase->get(self::ROOT . '/active_invoices/' . $slug);
        $invoice = $this->invoice((string) ($index['order_id'] ?? ''));
        return $invoice && ($invoice['slug'] ?? '') === $slug ? $invoice : null;
    }

    public function createInvoice(array $invoice, array $updates): void
    {
        $orderId = (string) $invoice['order_id'];
        $updates[self::ROOT . '/invoices/' . $orderId] = $invoice;
        $updates[self::ROOT . '/token_index/' . hash('sha256', (string) $invoice['public_token'])] = ['order_id' => $orderId];
        $updates[self::ROOT . '/active_invoices/' . $invoice['slug']] = ['order_id' => $orderId];
        $this->firebase->patch('', $updates);
    }

    public function updateInvoice(string $orderId, array $fields, array $updates = []): void
    {
        foreach ($fields as $name => $value) {
            $updates[self::ROOT . '/invoices/' . $orderId . '/' . $name] = $value;
        }
        $gatewayId = (string) ($fields['gateway_order_id'] ?? '');
        if ($gatewayId !== '') {
            $updates[self::ROOT . '/gateway_index/' . hash('sha256', $gatewayId)] = ['order_id' => $orderId];
        }
        $this->firebase->patch('', $updates);
    }

}

final class Firebase
{
    private ?string $accessToken = null;
    private ?array $authenticatedUser = null;

    private function accessToken(): string
    {
        if ($this->accessToken === null) {
            // Reuse short-lived Firebase access token across PHP requests on shared hosting.
            // File lives under backend/storage (outside public document root).
            $dir = dirname(__DIR__) . '/storage';
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $cachePath = $dir . '/firebase-access.json';
            $cached = @file_get_contents($cachePath);
            $value = $cached !== false ? json_decode($cached, true) : null;
            if (is_array($value) && !empty($value['token']) && (int) ($value['expires'] ?? 0) > time() + 90) {
                $this->accessToken = (string) $value['token'];
                return $this->accessToken;
            }
            $keyFile = Config::get('OGIPOS_FIREBASE_SERVICE_ACCOUNT');
            if ($keyFile === '' || !is_file($keyFile) || !is_readable($keyFile)) {
                throw new ApiError('File service account Firebase belum tersedia di luar document root.', 503);
            }
            $json = json_decode((string) file_get_contents($keyFile), true);
            if (!is_array($json) || empty($json['client_email']) || empty($json['private_key'])) {
                throw new ApiError('Service account Firebase tidak valid.', 503);
            }
            $encode = static fn(array $data): string => rtrim(strtr(base64_encode(
                json_encode($data, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)), '+/', '-_'), '=');
            $now = time();
            $unsigned = $encode(['alg' => 'RS256', 'typ' => 'JWT']) . '.' . $encode([
                'iss' => $json['client_email'],
                'scope' => 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email',
                'aud' => 'https://oauth2.googleapis.com/token',
                'iat' => $now, 'exp' => $now + 3600,
            ]);
            if (!openssl_sign($unsigned, $signature, $json['private_key'], OPENSSL_ALGO_SHA256)) {
                throw new ApiError('Tanda tangan kredensial Firebase gagal.', 503);
            }
            $assertion = $unsigned . '.' . rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
            $curl = curl_init('https://oauth2.googleapis.com/token');
            curl_setopt_array($curl, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 18,
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
                CURLOPT_POSTFIELDS => http_build_query([
                    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $assertion,
                ]),
            ]);
            $body = curl_exec($curl);
            $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);
            $response = $body !== false ? json_decode($body, true) : null;
            $this->accessToken = $response['access_token'] ?? '';
            if ($status !== 200 || !is_string($this->accessToken) || $this->accessToken === '') {
                throw new ApiError('Kredensial Firebase server tidak valid.', 503);
            }
            $payload = json_encode(['token' => $this->accessToken,
                'expires' => time() + max(120, (int) ($response['expires_in'] ?? 3600))], JSON_THROW_ON_ERROR);
            @file_put_contents($cachePath, $payload, LOCK_EX);
            @chmod($cachePath, 0600);
        }
        return $this->accessToken;
    }

    private function path(string $path): string
    {
        if (!preg_match('~^[a-zA-Z0-9_./-]*$~', $path) || str_contains($path, '..')) {
            throw new ApiError('Path database tidak valid.');
        }
        return rtrim(Config::need('OGIPOS_FIREBASE_DATABASE_URL'), '/') . '/' . ltrim($path, '/') . '.json';
    }

    public function get(string $path): array
    {
        return Web::request('GET', $this->path($path), null, ['Authorization: Bearer ' . $this->accessToken()]);
    }

    public function patch(string $path, array $value): void
    {
        Web::request('PATCH', $this->path($path), $value, ['Authorization: Bearer ' . $this->accessToken()]);
    }

    public function put(string $path, array $value): void
    {
        Web::request('PUT', $this->path($path), $value, ['Authorization: Bearer ' . $this->accessToken()]);
    }

    // Realtime Database ETag memberi transaksi lintas instance tanpa menyimpan state pada disk lokal.
    // Callback mengembalikan array baru, null untuk hapus, atau false untuk tidak mengubah.
    public function cas(string $path, callable $change, int $tries = 8): array
    {
        $url = $this->path($path);
        $auth = 'Authorization: Bearer ' . $this->accessToken();
        for ($attempt = 0; $attempt < $tries; $attempt++) {
            $etag = '';
            $curl = curl_init($url);
            curl_setopt_array($curl, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 18,
                CURLOPT_HTTPHEADER => [$auth, 'X-Firebase-ETag: true', 'Accept: application/json'],
                CURLOPT_HEADERFUNCTION => static function ($handle, string $header) use (&$etag): int {
                    if (stripos($header, 'etag:') === 0) $etag = trim(substr($header, 5));
                    return strlen($header);
                },
            ]);
            $body = curl_exec($curl);
            $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);
            if ($body === false || $status !== 200 || $etag === '') {
                throw new ApiError('Transaksi database belum tersedia.', 502);
            }
            $decoded = json_decode($body, true);
            if ($body !== 'null' && !is_array($decoded)) {
                throw new ApiError('Data transaksi database tidak valid.', 502);
            }
            $current = is_array($decoded) ? $decoded : null;
            $next = $change($current);
            if ($next === false) return ['written' => false, 'value' => $current];
            if ($next !== null && !is_array($next)) throw new ApiError('Transaksi database tidak valid.', 500);
            $writer = curl_init($url);
            curl_setopt_array($writer, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => 'PUT', CURLOPT_TIMEOUT => 18,
                CURLOPT_HTTPHEADER => [$auth, 'If-Match: ' . $etag, 'Content-Type: application/json'],
                CURLOPT_POSTFIELDS => json_encode($next, JSON_THROW_ON_ERROR),
            ]);
            $result = curl_exec($writer);
            $writeStatus = (int) curl_getinfo($writer, CURLINFO_RESPONSE_CODE);
            curl_close($writer);
            if ($result !== false && $writeStatus === 200) return ['written' => true, 'value' => $next];
            if ($writeStatus !== 412) throw new ApiError('Transaksi database gagal.', 502);
            usleep(random_int(10000, 40000));
        }
        throw new ApiError('Database sedang sibuk. Ulangi permintaan.', 503);
    }

    public function userInfo(): array
    {
        if ($this->authenticatedUser !== null) return $this->authenticatedUser;
        $token = Web::bearer();
        $url = 'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' . rawurlencode(Config::need('OGIPOS_FIREBASE_API_KEY'));
        try {
            $response = Web::request('POST', $url, ['idToken' => $token]);
        } catch (ApiError $error) {
            throw new ApiError('Sesi Firebase tidak valid atau kedaluwarsa.', 401);
        }
        $user = $response['users'][0] ?? [];
        if (empty($user['localId']) || !empty($user['disabled'])) {
            throw new ApiError('Akun Firebase tidak aktif.', 401);
        }
        return $this->authenticatedUser = $user;
    }

    public function uid(): string
    {
        return (string) $this->userInfo()['localId'];
    }

    public function owner(): array
    {
        $uid = $this->uid();
        $profile = $this->get('users/' . $uid);
        if (($profile['role'] ?? '') !== 'owner' || ($profile['tenantId'] ?? '') !== $uid || ($profile['active'] ?? false) !== true) {
            throw new ApiError('Hanya Owner yang dapat menyiapkan database.', 403);
        }
        return [$uid, $profile];
    }

    public function admin(): string
    {
        $uid = $this->uid();
        $admin = $this->get('ogipos_master/admins/' . $uid);
        if (($admin['role'] ?? '') !== 'super_admin' || ($admin['active'] ?? true) !== true) {
            throw new ApiError('Akses admin ditolak.', 403);
        }
        return $uid;
    }
}
