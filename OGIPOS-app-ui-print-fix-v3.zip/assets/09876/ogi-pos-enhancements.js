/* OGIPOS UI/printing enhancements — generated 2026-11-08 */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const money = (value) => 'Rp ' + Math.max(0, Number(value || 0)).toLocaleString('id-ID');
  const clean = (value) => String(value ?? '').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
  const wrap = (value, width = 32) => {
    const words = clean(value).split(' ');
    const lines = []; let line = '';
    for (const word of words) {
      if (!word) continue;
      if (word.length > width) {
        if (line) lines.push(line), line = '';
        for (let i = 0; i < word.length; i += width) lines.push(word.slice(i, i + width));
      } else if (!line) line = word;
      else if ((line + ' ' + word).length <= width) line += ' ' + word;
      else lines.push(line), line = word;
    }
    if (line) lines.push(line);
    return lines;
  };
  const center = (value, width = 32) => {
    const s = clean(value).slice(0, width);
    const left = Math.max(0, Math.floor((width - s.length) / 2));
    return ' '.repeat(left) + s;
  };
  const row = (label, value, width = 32) => {
    const l = clean(label), v = clean(value);
    const gap = Math.max(1, width - l.length - v.length);
    if (l.length + v.length + gap <= width) return [l + ' '.repeat(gap) + v];
    return [...wrap(l, width), ...wrap(v, width)];
  };
  const esc = (bytes) => new Uint8Array(bytes);
  const enc = (text) => new TextEncoder().encode(String(text) + '\n');
  const qr = (value, moduleSize = 5) => {
    const data = new TextEncoder().encode(String(value || ''));
    const n = data.length + 3;
    return [
      esc([0x1d,0x28,0x6b,0x04,0x00,0x31,0x41,0x32,0x00]),
      esc([0x1d,0x28,0x6b,0x03,0x00,0x31,0x43,moduleSize]),
      esc([0x1d,0x28,0x6b,0x03,0x00,0x31,0x45,0x31]),
      new Uint8Array([0x1d,0x28,0x6b,n & 255,(n >> 8) & 255,0x31,0x50,0x30,...data]),
      esc([0x1d,0x28,0x6b,0x03,0x00,0x31,0x51,0x30])
    ];
  };
  const isPaid = (order) => /lunas|paid|settled/i.test(String(order?.paymentStatus || order?.payment_status || order?.statusBayar || ''));
  const getOrder = () => {
    const id = clean($('nota-id')?.innerText);
    return (Array.isArray(orders) ? orders : []).find((o) => String(o.id) === id);
  };

  // Convert uploaded/default logo to a small 1-bit ESC/POS raster image.
  // This helper is defined here (not assumed to exist in the minified app bundle).
  let logoRasterCache = null;
  let logoRasterSource = '';
  async function buildReceiptLogoRaster(source, maxWidth = 224, maxHeight = 88) {
    const image = new Image();
    image.decoding = 'async';
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('Gambar logo tidak dapat dibaca.'));
      image.src = source;
    });
    const scale = Math.min(1, maxWidth / image.naturalWidth, maxHeight / image.naturalHeight);
    const width = Math.max(8, Math.floor(image.naturalWidth * scale));
    const height = Math.max(8, Math.floor(image.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const context = canvas.getContext('2d', { willReadFrequently: true, alpha: false });
    if (!context) throw new Error('Canvas logo tidak tersedia.');
    context.fillStyle = '#fff'; context.fillRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);
    const pixels = context.getImageData(0, 0, width, height).data;
    const rowBytes = Math.ceil(width / 8);
    const bitmap = new Uint8Array(rowBytes * height);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const luminance = 0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2];
        if (luminance < 166) bitmap[y * rowBytes + (x >> 3)] |= (0x80 >> (x & 7));
      }
    }
    const header = new Uint8Array([0x1d, 0x76, 0x30, 0x00, rowBytes & 0xff, (rowBytes >> 8) & 0xff, height & 0xff, (height >> 8) & 0xff]);
    const command = new Uint8Array(header.length + bitmap.length);
    command.set(header, 0); command.set(bitmap, header.length);
    return command;
  }
  window.appendReceiptLogoV3 = async function (payload) {
    const source = String(currentTenantData?.receiptLogo || currentTenantData?.logoNota || currentTenantData?.logo || '/assets/images/ogipos-mark.png');
    try {
      if (!logoRasterCache || source !== logoRasterSource) {
        logoRasterCache = await buildReceiptLogoRaster(source, 224, 88);
        logoRasterSource = source;
      }
      payload.push(esc([0x1b, 0x61, 0x01]), logoRasterCache, esc([0x0a]));
    } catch (error) { console.warn('Logo nota mono tidak dapat diproses:', error); }
  };

  // Compress every newly selected receipt logo to a small grayscale JPEG before saving.
  if (typeof window.clearReceiptLogo === 'function') {
    const originalClearReceiptLogo = window.clearReceiptLogo;
    window.clearReceiptLogo = function () {
      originalClearReceiptLogo();
      logoRasterCache = null;
      logoRasterSource = '';
    };
  }

  window.handleReceiptLogoInput = async function (input) {
    const file = input?.files?.[0];
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/i.test(file.type)) {
      input.value = ''; alert('Pilih file PNG, JPG, atau WebP.'); return;
    }
    if (file.size > 5 * 1024 * 1024) {
      input.value = ''; alert('Ukuran logo maksimal 5 MB sebelum kompresi.'); return;
    }
    try {
      const url = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        try {
          const maxW = 384, maxH = 160;
          const scale = Math.min(1, maxW / image.naturalWidth, maxH / image.naturalHeight);
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(8, Math.round(image.naturalWidth * scale));
          canvas.height = Math.max(8, Math.round(image.naturalHeight * scale));
          const ctx = canvas.getContext('2d', { alpha: false });
          ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
          const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
          for (let i = 0; i < pixels.data.length; i += 4) {
            const y = Math.round(0.299 * pixels.data[i] + 0.587 * pixels.data[i + 1] + 0.114 * pixels.data[i + 2]);
            const mono = y < 166 ? 0 : 255;
            pixels.data[i] = pixels.data[i + 1] = pixels.data[i + 2] = mono;
            pixels.data[i + 3] = 255;
          }
          ctx.putImageData(pixels, 0, 0);
          const compressed = canvas.toDataURL('image/jpeg', 0.72);
          pendingReceiptLogoDataUrl = compressed;
          logoRasterCache = null; logoRasterSource = '';
          if (typeof setReceiptLogoPreview === 'function') setReceiptLogoPreview(compressed);
          const kb = Math.max(1, Math.round((compressed.length * 3 / 4) / 1024));
          if (typeof triggerNotification === 'function') triggerNotification('Logo nota dikompres hitam-putih (' + kb + ' KB). Simpan profil usaha untuk menerapkan.');
        } finally { URL.revokeObjectURL(url); }
      };
      image.onerror = () => { URL.revokeObjectURL(url); input.value = ''; alert('Logo tidak dapat dibaca. Coba file gambar lain.'); };
      image.src = url;
    } catch (error) { console.error(error); alert('Kompresi logo gagal.'); }
  };

  // Receipt print: fixed-width text wrapping + native printer QR, without loading a full-color logo.
  window.printBluetoothReceipt = async function (button) {
    if (typeof setButtonBusy === 'function') setButtonBusy(button, true);
    try {
      if (!navigator.bluetooth) throw new Error('Gunakan Chrome melalui HTTPS dan aktifkan Bluetooth.');
      const order = getOrder();
      if (!order) throw new Error('Data nota tidak ditemukan.');
      const { characteristic } = await connectThermalPrinterV4();
      const p = [esc([0x1b,0x40]), esc([0x1b,0x61,0x01])];
      await appendReceiptLogoV3(p);
      p.push(esc([0x1b,0x61,0x01,0x1b,0x45,0x01]), enc(clean(tenantName || 'OGIPOS LAUNDRY').toUpperCase()), esc([0x1b,0x45,0x00]));
      const phone = clean(currentTenantData?.phone || currentTenantData?.whatsapp || '');
      const address = clean(currentTenantData?.address || '');
      if (phone) p.push(enc(center('Hub: ' + phone)));
      if (address) {
        // ESC M 1 selects the printer's compact Font B for the address only.
        p.push(esc([0x1b, 0x4d, 0x01]));
        wrap(address, 42).forEach(line => p.push(enc(center(line, 42))));
        p.push(esc([0x1b, 0x4d, 0x00]));
      }
      p.push(enc(center(new Date(order.date || Date.now()).toLocaleString('id-ID'))));
      p.push(enc('--------------------------------'));
      const width = 32;
      row('No Nota:', order.id, width).forEach(x => p.push(enc(x)));
      row('Kasir:', order.cashier || currentCashier || '-', width).forEach(x => p.push(enc(x)));
      row('Konsumen:', order.customer || order.customerName || order.customer_name || '-', width).forEach(x => p.push(enc(x)));
      row('Estimasi:', order.estimatedPickup ? new Date(order.estimatedPickup).toLocaleString('id-ID') : '-', width).forEach(x => p.push(enc(x)));
      p.push(enc('--------------------------------'), enc('RINCIAN LAYANAN'));
      let items = order.items || order.itemsDetail || [];
      if (typeof items === 'string') { try { items = JSON.parse(items); } catch { items = []; } }
      if (Array.isArray(items) && items.length) {
        items.forEach(item => {
          wrap(item.name || item.service || 'Layanan').forEach(x => p.push(enc(x)));
          const qty = Number(item.qty || item.quantity || 1);
          const price = Number(item.price || 0);
          const total = Number(item.lineTotal || item.total || price * qty);
          const detail = `${qty} x ${money(price)} = ${money(total)}`;
          wrap(detail).forEach(x => p.push(enc(x)));
        });
      } else wrap(order.service || 'Rincian tidak tersedia').forEach(x => p.push(enc(x)));
      p.push(enc('--------------------------------'));
      row('Subtotal:', money(order.subtotal ?? order.total), width).forEach(x => p.push(enc(x)));
      row('Diskon:', money(order.discount), width).forEach(x => p.push(enc(x)));
      row('Dibayar:', money(order.paidAmount ?? order.cashPaid ?? order.total), width).forEach(x => p.push(enc(x)));
      row('Kembalian:', money(order.change ?? order.cashChange), width).forEach(x => p.push(enc(x)));
      p.push(esc([0x1b,0x45,0x01]), ...row('TOTAL:', money(order.grandTotal ?? order.total), width).map(enc), esc([0x1b,0x45,0x00]));
      p.push(enc('--------------------------------'));
      row('Metode:', order.method || order.paymentMethod || 'Tunai / Cash', width).forEach(x => p.push(enc(x)));
      row('Status:', isPaid(order) ? 'LUNAS' : 'BELUM BAYAR', width).forEach(x => p.push(enc(x)));
      p.push(enc('--------------------------------'), esc([0x1b,0x61,0x01]), ...qr(buildTrackingUrl(order.id), 5), enc('Scan QR untuk tracking'), esc([0x1b,0x61,0x01]), enc('Terima kasih'), esc([0x1b,0x64,0x04]));
      await writePrinterPayloadV3(characteristic, p);
      if (typeof triggerNotification === 'function') triggerNotification('Nota tercetak dengan teks rata dan logo hitam-putih.');
    } catch (error) {
      console.error('OGIPOS receipt print:', error);
      alert(error?.message || 'Nota belum dapat dicetak. Periksa printer Bluetooth.');
    } finally { if (typeof setButtonBusy === 'function') setButtonBusy(button, false); }
  };

  // Laundry label: tracking QR + large, unmistakable payment-status box.
  window.printLaundryLabel = async function (button) {
    if (typeof setButtonBusy === 'function') setButtonBusy(button, true);
    try {
      if (!navigator.bluetooth) throw new Error('Gunakan Chrome melalui HTTPS dan aktifkan Bluetooth.');
      const order = getOrder();
      if (!order) throw new Error('Data pesanan tidak ditemukan.');
      const { characteristic } = await connectThermalPrinterV4();
      const paid = isPaid(order);
      const status = paid ? 'LUNAS' : 'BELUM BAYAR';
      const p = [esc([0x1b,0x40]), esc([0x1b,0x61,0x01])];
      await appendReceiptLogoV3(p);
      p.push(esc([0x1b,0x45,0x01]), enc(center(clean(tenantName || 'OGIPOS').toUpperCase())), esc([0x1b,0x45,0x00]));
      p.push(enc('================================'), enc(center('LABEL PESANAN')), enc('================================'));
      wrap('NO: ' + order.id).forEach(x => p.push(enc(x)));
      const customerName = clean(order.customer || order.customerName || order.customer_name || '-');
      p.push(esc([0x1b,0x61,0x01]), enc('PELANGGAN'), esc([0x1b,0x45,0x01,0x1d,0x21,0x11]));
      wrap(customerName, 16).forEach(line => p.push(enc(center(line, 16))));
      p.push(esc([0x1d,0x21,0x00,0x1b,0x45,0x00]), esc([0x1b,0x61,0x00]));
      wrap('Layanan: ' + (order.service || (Array.isArray(order.items) ? order.items.map(x => x.name).join(', ') : '-'))).forEach(x => p.push(enc(x)));
      wrap('Masuk: ' + new Date(order.date || Date.now()).toLocaleString('id-ID')).forEach(x => p.push(enc(x)));
      wrap('Ambil: ' + (order.estimatedPickup ? new Date(order.estimatedPickup).toLocaleString('id-ID') : '-')).forEach(x => p.push(enc(x)));
      p.push(enc('--------------------------------'), esc([0x1b,0x61,0x01]), enc('+------------------------------+'), esc([0x1b,0x45,0x01,0x1d,0x21,0x11]), enc(status), esc([0x1d,0x21,0x00,0x1b,0x45,0x00]), enc('+------------------------------+'), enc('--------------------------------'));
      p.push(esc([0x1b,0x61,0x01]), ...qr(buildTrackingUrl(order.id), 6), enc('SCAN QR PESANAN'), enc('Cek status dan detail pesanan'), esc([0x1b,0x64,0x04]));
      await writePrinterPayloadV3(characteristic, p);
      if (typeof triggerNotification === 'function') triggerNotification('Label pesanan dengan QR dan status ' + status + ' berhasil dikirim ke printer.');
    } catch (error) {
      console.error('OGIPOS label print:', error);
      alert(error?.message || 'Label belum dapat dicetak. Periksa printer Bluetooth.');
    } finally { if (typeof setButtonBusy === 'function') setButtonBusy(button, false); }
  };

  // Dedicated service-management screen; keep the POS surface focused on search/categories/cart.
  // The service cards are cloned as DOM nodes, then their computed visual styles are
  // copied from the live cashier cards. This preserves the exact icon/image proportions,
  // typography and internal spacing even though the management page is outside #view-pos.
  const SERVICE_STYLE_PROPS = [
    'display','position','box-sizing','flex','flex-direction','flex-wrap','flex-grow','flex-shrink','flex-basis',
    'align-items','align-content','align-self','justify-content','gap','row-gap','column-gap',
    'padding','padding-top','padding-right','padding-bottom','padding-left','margin','margin-top','margin-right','margin-bottom','margin-left',
    'color','background','background-color','background-image','background-position','background-size','background-repeat',
    'border','border-top','border-right','border-bottom','border-left','border-radius','border-color','border-width','border-style',
    'box-shadow','font','font-family','font-size','font-style','font-weight','line-height','letter-spacing','text-align','text-decoration',
    'white-space','overflow','overflow-wrap','word-break','text-overflow','-webkit-line-clamp','-webkit-box-orient',
    'aspect-ratio','object-fit','object-position','min-height','max-height','min-width','max-width',
    'width','height','top','right','bottom','left','z-index','opacity','transform','filter','isolation','pointer-events'
  ];
  function copyServiceAppearance(source, clone, isRoot = false) {
    if (!source || !clone) return;
    const computed = getComputedStyle(source);
    for (const property of SERVICE_STYLE_PROPS) {
      if (isRoot && ['width','height','max-width','min-width','top','right','bottom','left'].includes(property)) continue;
      const value = computed.getPropertyValue(property);
      if (value) clone.style.setProperty(property, value);
    }
    // Carry OGIPOS theme variables used by service picture variants.
    for (let i = 0; i < computed.length; i++) {
      const property = computed[i];
      if (property.startsWith('--ogi-')) clone.style.setProperty(property, computed.getPropertyValue(property));
    }
    const sourceChildren = source.children || [];
    const cloneChildren = clone.children || [];
    for (let i = 0; i < Math.min(sourceChildren.length, cloneChildren.length); i++) {
      copyServiceAppearance(sourceChildren[i], cloneChildren[i], false);
    }
  }
  function syncServiceManager() {
    const source = $('services-grid'), target = $('services-management-grid');
    if (!source || !target) return;
    target.className = 'ogi-service-manager-grid';
    target.replaceChildren();
    Array.from(source.children).forEach(sourceCard => {
      const card = sourceCard.cloneNode(true);
      card.removeAttribute('onclick');
      card.removeAttribute('onkeydown');
      copyServiceAppearance(sourceCard, card, true);
      card.style.width = 'auto';
      card.style.maxWidth = '100%';
      card.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', event => event.stopPropagation());
      });
      target.appendChild(card);
    });
    const q = clean($('service-management-search')?.value).toLowerCase();
    target.querySelectorAll(':scope > *').forEach(card => {
      card.hidden = !!q && !card.textContent.toLowerCase().includes(q);
    });
  }
  if (typeof renderServicesGrid === 'function') {
    const originalRenderServicesGrid = renderServicesGrid;
    window.renderServicesGrid = function () { originalRenderServicesGrid(); syncServiceManager(); };
  }
  if (typeof APP_VIEW_PATHS === 'object') APP_VIEW_PATHS.services = 'layanan';

  // Ensure payment buttons are available on the very first checkout, not only after a prior order.
  function ensurePaymentMethods() {
    const grid = $('cart-payment-grid'), input = $('cart-payment');
    if (!grid || !input) return;
    const methods = ['Tunai / Cash', 'QRIS', 'Debit'];
    if (grid.querySelectorAll('[data-payment-method]').length !== methods.length) {
      grid.innerHTML = methods.map((method, index) => `<button type="button" class="ogi-payment-choice${index === 0 ? ' is-selected' : ''}" data-payment-method="${String(method).replace(/[&<>"']/g, '')}" aria-pressed="${index === 0 ? 'true' : 'false'}">${String(method).replace(/\/ Cash/i, '').replace(/[&<>"']/g, '')}</button>`).join('');
    }
    if (!methods.includes(input.value)) input.value = methods[0];
    grid.querySelectorAll('[data-payment-method]').forEach(button => {
      if (button.dataset.ogiBound === '1') return;
      button.dataset.ogiBound = '1';
      button.addEventListener('click', () => {
        input.value = button.dataset.paymentMethod;
        grid.querySelectorAll('[data-payment-method]').forEach(item => {
          const active = item === button;
          item.classList.toggle('is-selected', active);
          item.setAttribute('aria-pressed', String(active));
        });
        const cash = /tunai|cash/i.test(input.value);
        const cashWrap = $('wrapper-cash-calculation');
        if (cashWrap) cashWrap.classList.toggle('hidden', !cash);
        const cashInput = $('cart-cash-paid');
        if (!cash && cashInput) cashInput.value = '';
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  }
  document.addEventListener('click', event => {
    const trigger = event.target.closest('[onclick*="openPaymentModalV3"], .ogi-btn-paid');
    if (trigger) setTimeout(ensurePaymentMethods, 80);
  }, true);
  const paymentModal = $('ogi-payment-modal');
  if (paymentModal) new MutationObserver(ensurePaymentMethods).observe(paymentModal, { attributes: true, attributeFilter: ['class', 'aria-hidden'] });

  document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('#app-sidebar nav');
    if (nav && !$('nav-services-management')) {
      const button = document.createElement('button');
      button.id = 'nav-services-management'; button.type = 'button';
      button.className = 'nav-btn sidebar-nav-btn'; button.dataset.roles = 'owner,admin';
      button.innerHTML = '<i class="fa-solid fa-boxes-stacked"></i><span>Kelola Layanan</span>';
      button.setAttribute('onclick', "switchView('services')");
      button.addEventListener('click', (event) => { if (!['owner', 'admin'].includes(currentRole)) { event.preventDefault(); event.stopImmediatePropagation(); alert('Halaman Kelola Layanan hanya tersedia untuk Owner dan Admin.'); return; } setTimeout(syncServiceManager, 80); });
      const posButton = Array.from(nav.querySelectorAll('.nav-btn')).find(el => (el.getAttribute('onclick') || '').includes("switchView('pos')"));
      if (posButton) posButton.after(button); else nav.prepend(button);
      const roleTimer = setInterval(() => { if (currentRole) { button.hidden = !['owner', 'admin'].includes(currentRole); clearInterval(roleTimer); } }, 500);
    }
    const main = document.querySelector('#main-app main');
    if (main && !$('view-services')) {
      const section = document.createElement('section');
      section.id = 'view-services'; section.className = 'view-section hidden w-full space-y-4'; section.dataset.roles = 'owner,admin';
      section.innerHTML = `<div class="ogi-service-manager-head"><div><span class="ogi-eyebrow">KATALOG USAHA</span><h2>Kelola Layanan</h2><p>Tambah, ubah, dan hapus layanan laundry. Katalog ini digunakan langsung oleh kasir.</p></div><button type="button" class="ogi-service-manager-add" onclick="openNewServiceModal()"><i class="fa-solid fa-plus"></i> Tambah Layanan</button></div><div class="ogi-service-manager-tools"><input id="service-management-search" type="search" placeholder="Cari layanan untuk dikelola…" aria-label="Cari layanan" /><span>Kelola harga, kategori, satuan, dan layanan aktif.</span></div><div id="services-management-grid" class="ogi-service-manager-grid" aria-label="Daftar layanan yang dapat dikelola"></div>`;
      const pos = $('view-pos'); if (pos) pos.after(section); else main.append(section);
      $('service-management-search').addEventListener('input', syncServiceManager);
    }
    syncServiceManager();
    window.addEventListener('resize', () => requestAnimationFrame(syncServiceManager), { passive: true });
    const sourceGrid = $('services-grid');
    if (sourceGrid && !sourceGrid.dataset.ogiObserved) {
      sourceGrid.dataset.ogiObserved = '1';
      new MutationObserver(syncServiceManager).observe(sourceGrid, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] });
    }
    const trialAction = $('ogi-trial-action');
    if (trialAction) {
      const syncTrialActionRole = () => {
        const role = String(typeof currentRole !== 'undefined' ? currentRole : '').toLowerCase();
        if (role === 'owner') { trialAction.classList.remove('hidden'); trialAction.hidden = false; return true; }
        if (role && role !== 'owner') { trialAction.classList.add('hidden'); trialAction.hidden = true; return true; }
        return false;
      };
      if (!syncTrialActionRole()) {
        let attempts = 0;
        const roleTimer = setInterval(() => { attempts++; if (syncTrialActionRole() || attempts >= 80) clearInterval(roleTimer); }, 250);
      }
    }
    const logoHelp = document.querySelector('#setting-logo-file')?.previousElementSibling?.querySelector('p');
    if (logoHelp) logoHelp.textContent = 'Logo ini akan dicetak pada nota dan label Bluetooth. OGIPOS otomatis mengubahnya menjadi hitam-putih berukuran ringan agar pencetakan lebih cepat.';
    const grid = $('cart-payment-grid'); if (grid) ensurePaymentMethods();
  });

  // Scoped, non-overlapping layouts. The banner uses flex wrapping instead of a
  // four-column grid that could collide with legacy .ogi-trial-ribbon rules.
  const style = document.createElement('style');
  style.id = 'ogipos-stable-layout-fix';
  style.textContent = `
    #tenant-plan-strip.ogi-trial-banner:not(.hidden){display:flex!important;flex-flow:row wrap!important;align-items:center!important;gap:12px!important;margin:12px 18px 0!important;padding:14px 16px!important;min-height:0!important;height:auto!important;overflow:visible!important;border:1px solid #ead9a8!important;border-radius:16px!important;background:#fffaf0!important;box-shadow:none!important;color:#263246!important}
    #tenant-plan-strip .ogi-trial-emblem{display:grid!important;place-items:center!important;flex:0 0 46px!important;width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;margin:0!important;border-radius:14px!important;background:#fff0c8!important;font-size:22px!important}
    #tenant-plan-strip .ogi-trial-copy{display:flex!important;flex:1 1 220px!important;flex-direction:column!important;gap:4px!important;min-width:0!important;margin:0!important}
    #tenant-plan-strip .ogi-trial-copy strong{display:block!important;margin:0!important;color:#263246!important;font-size:16px!important;font-weight:850!important;line-height:1.25!important;overflow-wrap:anywhere!important}
    #tenant-plan-strip .ogi-trial-copy span{display:block!important;margin:0!important;color:#667085!important;font-size:12px!important;line-height:1.45!important;white-space:normal!important;overflow-wrap:anywhere!important}
    #tenant-plan-strip .ogi-trial-status{display:flex!important;flex:0 1 160px!important;flex-direction:column!important;gap:6px!important;min-width:110px!important;max-width:180px!important;margin:0!important}
    #tenant-plan-strip .ogi-trial-status b{display:flex!important;align-items:center!important;justify-content:center!important;min-height:32px!important;margin:0!important;padding:6px 9px!important;border:1px solid #ecdba9!important;border-radius:9px!important;background:#fff1c9!important;color:#805b13!important;font-size:11px!important;font-weight:800!important;line-height:1.3!important;text-align:center!important;white-space:normal!important}
    #tenant-plan-strip .ogi-trial-progress-track{display:block!important;width:100%!important;height:6px!important;margin:0!important;border-radius:20px!important;background:#eee6d4!important;overflow:hidden!important}
    #tenant-plan-strip .ogi-trial-progress{display:block!important;height:100%!important;border-radius:20px!important;background:#d6a43c!important}
    #tenant-plan-strip .ogi-trial-action:not(.hidden):not([hidden]){display:inline-flex!important;flex:0 0 auto!important;align-items:center!important;justify-content:center!important;gap:7px!important;width:auto!important;min-width:142px!important;max-width:100%!important;min-height:42px!important;margin:0!important;padding:10px 13px!important;border:1px solid #116b63!important;border-radius:10px!important;background:#147c72!important;color:#fff!important;font-size:11px!important;font-weight:850!important;line-height:1.2!important;white-space:normal!important;text-align:center!important;text-decoration:none!important;box-shadow:none!important}
    #tenant-plan-strip .ogi-trial-action.hidden,#tenant-plan-strip .ogi-trial-action[hidden]{display:none!important}
    #tenant-plan-strip .ogi-trial-action *{color:inherit!important;font-size:inherit!important;line-height:inherit!important}
    #view-services{width:100%;max-width:1120px;margin:0 auto;min-width:0}
    .ogi-service-manager-head{display:flex;justify-content:space-between;align-items:center;gap:16px;padding:20px;border:1px solid #e7ebee;border-radius:16px;background:#fff}
    .ogi-service-manager-head h2{margin:4px 0;font-size:21px;font-weight:850;color:#1f2937;letter-spacing:-.03em}
    .ogi-service-manager-head p,.ogi-service-manager-tools span{margin:0;color:#77808d;font-size:12px;line-height:1.5}
    .ogi-eyebrow{font-size:10px;font-weight:800;letter-spacing:.15em;color:#147c72}
    .ogi-service-manager-add{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 15px;border:0;border-radius:11px;background:#147c72;color:#fff;font-size:12px;font-weight:800;white-space:nowrap}
    .ogi-service-manager-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 15px;border:1px solid #e7ebee;border-radius:13px;background:#fff}
    .ogi-service-manager-tools input{width:min(100%,360px);height:40px;padding:0 12px;border:1px solid #e2e7eb;border-radius:9px;background:#f8fafb;font-size:12px;outline:none}
    .ogi-service-manager-grid{display:grid!important;grid-template-columns:repeat(auto-fill,minmax(min(100%,165px),1fr))!important;align-content:start!important;align-items:stretch!important;gap:12px!important;width:100%!important;min-width:0!important;margin:0!important;padding:0!important}
    .ogi-service-manager-grid>.service-card-v3{position:relative!important;display:flex!important;flex-direction:column!important;justify-content:space-between!important;gap:6px!important;width:auto!important;min-width:0!important;max-width:100%!important;min-height:150px!important;height:auto!important;padding:10px!important;overflow:hidden!important;border:1px solid #e5eaf1!important;border-radius:14px!important;background:#fff!important;color:#1e293b!important;box-shadow:none!important;transform:none!important}
    .ogi-service-manager-grid .ogi-service-picture{position:relative!important;display:grid!important;place-items:center!important;width:100%!important;min-width:0!important;min-height:78px!important;max-height:130px!important;height:auto!important;aspect-ratio:1.62/1!important;overflow:hidden!important;border-radius:10px!important;object-fit:cover!important}
    .ogi-service-manager-grid .ogi-service-picture img{display:block!important;width:100%!important;height:100%!important;max-width:100%!important;object-fit:cover!important}
    .ogi-service-manager-grid .ogi-service-pictogram{font-size:clamp(29px,3.8vw,46px)!important;line-height:1!important}
    .ogi-service-manager-grid .ogi-service-description{display:flex!important;flex:1 1 auto!important;flex-direction:column!important;justify-content:space-between!important;gap:7px!important;min-width:0!important;padding:8px 4px 3px!important}
    .ogi-service-manager-grid .ogi-service-description h4{display:block!important;min-height:0!important;margin:0!important;color:#214450!important;font-size:13px!important;font-weight:800!important;line-height:1.3!important;overflow-wrap:anywhere!important}
    .ogi-service-manager-grid .ogi-service-price{display:flex!important;align-items:flex-end!important;justify-content:space-between!important;gap:6px!important;min-width:0!important}
    .ogi-service-manager-grid .ogi-service-price strong{flex:0 0 auto!important;color:#147c72!important;font-size:13px!important;font-weight:850!important;white-space:nowrap!important}.ogi-service-manager-grid .ogi-service-price small{flex:0 0 auto!important;font-size:10px!important;white-space:nowrap!important}
    .ogi-service-manager-grid .ogi-service-manage{position:absolute!important;top:6px!important;right:6px!important;display:flex!important;gap:4px!important;z-index:4!important}
    .ogi-service-manager-grid .ogi-service-manage button{display:grid!important;place-items:center!important;width:27px!important;height:27px!important;min-width:27px!important;padding:0!important;border:1px solid #dce5e7!important;border-radius:8px!important;background:#fff!important;color:#52666b!important;box-shadow:none!important}
    .ogi-service-manager-grid [hidden]{display:none!important}
    #cart-payment-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
    #cart-payment-grid .ogi-payment-choice{min-height:46px;padding:9px 8px;border:1px solid #dfe5e8;border-radius:10px;background:#fff;color:#475467;font-size:12px;font-weight:750}
    #cart-payment-grid .ogi-payment-choice.is-selected{border-color:#147c72;background:#eaf6f3;color:#11685f;box-shadow:inset 0 0 0 1px #147c72}
    #view-dashboard [class*="shadow"]{box-shadow:none!important}
    @media(max-width:760px){#tenant-plan-strip.ogi-trial-banner:not(.hidden){gap:9px!important;margin:10px 12px 0!important;padding:12px!important}#tenant-plan-strip .ogi-trial-emblem{flex-basis:40px!important;width:40px!important;height:40px!important;min-width:40px!important;min-height:40px!important}#tenant-plan-strip .ogi-trial-copy{flex:1 1 calc(100% - 52px)!important}#tenant-plan-strip .ogi-trial-status{flex:1 1 135px!important;max-width:none!important;min-width:0!important;padding-left:49px!important}#tenant-plan-strip .ogi-trial-action:not(.hidden):not([hidden]){flex:0 1 auto!important;width:auto!important;min-width:142px!important} .ogi-service-manager-head{align-items:stretch;flex-direction:column}.ogi-service-manager-add{width:100%}.ogi-service-manager-tools{align-items:stretch;flex-direction:column}.ogi-service-manager-tools input{width:100%}.ogi-service-manager-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important}.ogi-service-manager-grid>.service-card-v3{min-height:145px!important;padding:9px!important}}
    @media(max-width:380px){#tenant-plan-strip .ogi-trial-status{flex:1 1 100%!important;padding-left:0!important}#tenant-plan-strip .ogi-trial-action:not(.hidden):not([hidden]){flex:1 1 100%!important;width:100%!important}#cart-payment-grid{gap:6px}#cart-payment-grid .ogi-payment-choice{font-size:11px;padding:8px 4px}.ogi-service-manager-grid{gap:8px!important}.ogi-service-manager-grid>.service-card-v3{padding:8px!important}}
  `;
  document.head.appendChild(style);
})();
