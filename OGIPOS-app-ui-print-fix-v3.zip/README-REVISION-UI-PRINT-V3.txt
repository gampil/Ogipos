OGIPOS APP — STABLE UI REVISION V3
Tanggal: 8 November 2026

FOKUS PERBAIKAN
1. Grid Kelola Layanan tidak lagi menyalin innerHTML mentah. Kartu diklon sebagai node DOM dan computed visual styles kartu Kasir beserta turunannya disalin agar proporsi gambar, ikon, tipografi, tombol CRUD, dan spacing tetap konsisten. Ukuran kartu root tetap responsif; grid Kelola Layanan memakai 2 kolom di mobile dan auto-fill pada layar lebih lebar.
2. Banner Trial memakai flex-wrap responsif, bukan grid 4 kolom yang bertabrakan dengan aturan .ogi-trial-ribbon lama. Isi tombol asli dipertahankan; tidak lagi ditimpa oleh script. Status dan CTA ditata dalam baris terpisah pada layar kecil.
3. Menghapus aturan grid span tambahan yang dapat mengubah layout Kasir.
4. Mempertahankan fungsi cetak logo raster hitam-putih, nota, label QR, status pembayaran, halaman Kelola Layanan, dan inisialisasi metode pembayaran dari patch sebelumnya.
5. Cache Service Worker dan query script dinaikkan ke V3 agar browser mengambil file revisi baru.

FILE UTAMA YANG BERUBAH
- index.html
- sw.js
- assets/09876/ogi-pos-enhancements.js

PEMASANGAN
1. Backup folder app yang sedang aktif.
2. Ekstrak ZIP ke document root frontend (folder yang berisi index.html).
3. Timpa file sesuai struktur; jangan unggah ke backend/API.
4. Tutup tab OGIPOS, buka ulang, lalu lakukan refresh. Jika service worker lama masih aktif, hapus data situs/cache OGIPOS dari Chrome lalu buka ulang.

QA LOKAL
- JavaScript syntax check: lulus untuk seluruh file JS pada assets/09876.
- HTML parser check: lulus untuk halaman HTML utama dan halaman pendukung.
- Pemeriksaan referensi aset lokal: lulus.
- Pemeriksaan struktur script: clone DOM dan copy computed style, tanpa mengganti isi CTA Trial.
- Pengujian printer Bluetooth fisik dan uji transaksi Firebase produksi tetap harus dilakukan setelah deployment.
