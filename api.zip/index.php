<?php
declare(strict_types=1);

use Ogipos\ApiError;
use Ogipos\Config;
use Ogipos\Firebase;
use Ogipos\GoogleAccount;
use Ogipos\Payments;
use Ogipos\Pos;
use Ogipos\Store;
use Ogipos\Web;

// Private runtime must be outside every domain document root.
$privateRoot = getenv('OGIPOS_PRIVATE_ROOT') ?: dirname(__DIR__) . '/private/ogipos-api';
$privateRoot = rtrim($privateRoot, DIRECTORY_SEPARATOR);
if (!is_file($privateRoot . '/src/Core.php') || !is_readable($privateRoot . '/.env')) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['ok' => false, 'error' => 'Konfigurasi API belum siap.']);
    exit;
}
require $privateRoot . '/src/Core.php';
Config::load($privateRoot . '/.env');
foreach (['Google', 'Sheets', 'InvoicePdf', 'Notifications', 'Payments', 'Pos', 'Registration'] as $module) {
    require $privateRoot . '/src/' . $module . '.php';
}

try {
    Web::cors();
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($method === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
    $path = rtrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/');
    if ($path === '') $path = '/';
    if ($path === '/v1/health' && $method === 'GET') {
        $ready = false;
        try {
            $firebaseReady = new Firebase();
            $firebaseReady->get('ogipos_master/system');
            GoogleAccount::driveReady();
            $ready = (new Store($firebaseReady))->legacyCutoffMs() > 0;
        } catch (Throwable $error) { error_log('OGIPOS health: ' . $error->getMessage()); }
        Web::json(['ok' => $ready, 'service' => 'OGIPOS PHP API',
            'sheetsReady' => $ready, 'googleConnected' => $ready], $ready ? 200 : 503);
    }

    // OAuth callback is validated with a one-use state, created only by authenticated super admin.
    if ($path === '/v1/oauth/google/callback' && $method === 'GET') {
        GoogleAccount::complete($_GET);
        header('Location: https://admin.' . Config::get('OGIPOS_BASE_DOMAIN', 'ogipos.com') . '/google-drive?google=connected', true, 303);
        exit;
    }
    $firebase = new Firebase();
    $store = new Store($firebase);
    if ($path === '/v1/admin/google/connect' && $method === 'POST') {
        $adminUid = $firebase->admin();
        Web::json(['ok' => true, 'url' => GoogleAccount::connectUrl($adminUid)]);
    }

    if (in_array($path, ['/v1/admin/sheets/status', '/v1/admin/google/status'], true) && $method === 'GET') {
        $firebase->admin();
        Web::json(GoogleAccount::status());
    }
    if ($path === '/v1/account/verified' && $method === 'POST') {
        Web::json((new \Ogipos\Notifications($firebase, $store))->confirmVerifiedAccount());
    }
    if ($path === '/v1/tenants/draft' && $method === 'POST') {
        $store->guardRate('registration-draft-ip-' . Web::remoteIp(), 30, 3600);
        Web::json((new \Ogipos\Registration($store, $firebase))->saveDraft(Web::input()));
    }
    if ($path === '/v1/tenants/draft' && $method === 'GET') {
        Web::json((new \Ogipos\Registration($store, $firebase))->getDraft());
    }
    if ($path === '/v1/tenants/register' && $method === 'POST') {
        $store->guardRate('registration-ip-' . Web::remoteIp(), 30, 3600);
        Web::json((new \Ogipos\Registration($store, $firebase))->register(Web::input()));
    }
    if ($path === '/v1/tenants/cloud-diagnostic' && $method === 'GET') {
        Web::json((new Pos($store, $firebase))->diagnose());
    }
    if ($path === '/v1/tenants/provision' && $method === 'POST') {
        Web::json((new Pos($store, $firebase))->provision());
    }
    if ($path === '/v1/pos' && $method === 'POST') {
        Web::json((new Pos($store, $firebase))->handle(Web::input()));
    }
    if ($path === '/v1/track' && $method === 'GET') {
        $slug = Web::slug((string) ($_GET['tenantSlug'] ?? ''));
        $store->guardRate('track-' . $slug, 600, 3600);
        Web::json((new Pos($store, $firebase))->track($slug, (string) ($_GET['order'] ?? '')));
    }
    if ($path === '/v1/payments' && $method === 'POST') {
        Web::json((new Payments($store, $firebase))->create((string) (Web::input()['tenantSlug'] ?? '')));
    }
    if (preg_match('~^/v1/checkout/([a-z0-9-]{3,30})$~', $path, $match) && $method === 'GET') {
        Web::json((new Payments($store, $firebase))->checkout($match[1]));
    }
    if (preg_match('~^/v1/payments/([a-f0-9]{64})/invoice\.pdf$~', $path, $match) && $method === 'GET') {
        $pdf = (new Payments($store, $firebase))->pdf($match[1]);
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="OGIPOS-Invoice.pdf"');
        header('Cache-Control: private, no-store');
        echo $pdf; exit;
    }
    if (preg_match('~^/v1/payments/([a-f0-9]{64})/invoice-email$~', $path, $match) && $method === 'POST') {
        Web::json((new Payments($store, $firebase))->sendInvoiceEmail($match[1]));
    }
    if (preg_match('~^/v1/payments/([a-f0-9]{64})/reconcile$~', $path, $match) && $method === 'POST') {
        Web::json((new Payments($store, $firebase))->reconcile($match[1]));
    }
    if (preg_match('~^/v1/payments/([a-f0-9]{64})$~', $path, $match) && $method === 'GET') {
        $store->guardRate('detail-' . hash('sha256', $match[1]), 300, 3600);
        Web::json((new Payments($store, $firebase))->detail($match[1]));
    }
    // GET is a harmless route diagnostic, not a payment confirmation.
    // If this URL returns 404 HTML, the hosting rewrite/document root is wrong.
    if ($path === '/v1/webhooks/cashi' && $method === 'GET') {
        header('Allow: POST, OPTIONS');
        Web::json(['ok' => false, 'route' => 'cashi-webhook', 'message' => 'Endpoint aktif. Cashi harus mengirim POST dengan X-Gateway-Signature.'], 405);
    }
    if ($path === '/v1/webhooks/cashi' && $method === 'POST') {
        $raw = file_get_contents('php://input') ?: '';
        if (strlen($raw) > 65536) throw new ApiError('Payload callback terlalu besar.', 413);
        Web::json((new Payments($store, $firebase))->webhook($raw));
    }
    if ($path === '/v1/admin/payments' && $method === 'POST') {
        $firebase->admin();
        throw new ApiError('Invoice aktivasi hanya dapat dibuat Owner dari dashboard usahanya.', 403);
    }
    if (preg_match('~^/v1/admin/payments/(OGI[A-F0-9]{20})/query$~', $path, $match) && $method === 'POST') {
        Web::json((new Payments($store, $firebase))->queryAdmin($match[1]));
    }
    if (preg_match('~^/v1/admin/payments/(OGI[A-F0-9]{20})$~', $path, $match) && $method === 'GET') {
        Web::json((new Payments($store, $firebase))->detailAdmin($match[1]));
    }
    Web::json(['ok' => false, 'error' => 'Rute API tidak ditemukan.'], 404);
} catch (ApiError $error) {
    Web::json(['ok' => false, 'error' => $error->getMessage()], $error->status);
} catch (Throwable $error) {
    error_log('OGIPOS API error: ' . $error);
    Web::json(['ok' => false, 'error' => 'Server belum dapat memproses permintaan.'], 500);
}
