<?php
declare(strict_types=1);
$_SERVER['REQUEST_URI'] = '/v1/webhooks/cashi';
require __DIR__ . '/index.php';
